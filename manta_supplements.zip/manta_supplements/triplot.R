#' @title PCoA for microbial sequencing data
#'
#' @description A wrapper around various PCoA-based analyses implemented in vegan. The wrapper can handle groups and
#' metadata. The na.action is set to na.omit, however envfit cannot deal with
#' missing values, therefore if metadata are provided, they should be free of missing values.
#'
#' @param data phyloseq object with sample data and taxonomy
#' @param tax_label taxonomic level used to label correlating taxa
#' @param selected_taxa if not significant taxa but listed taxa should be plotted, specify taxonomic names here; and level as tax_label
#' @param arrowColor the colour of the arrows can help distinguish text labels from arrows
#' @param groupAttrib the name of a metadata item that refers to a vector that provides for each sample its group membership
#' @param clusterAttrib attribute in metadata used for assigning node shape (cluster membership is visualized through shape, up to 8 different shapes are possible)
#' @param clusterTaxon vector of cluster assignments, generates vectors for clustered or grouped taxon abundances 
#' @param reference an optional matrix with taxa as rows and samples as columns, coming from another study
#' @param dis dissimilarity or distance supported by vegan
#' @param rda carry out an RDA using vegan
#' @param scale scale numeric metadata (subtract the mean and divide by standard deviation)
#' @param doScree do a Scree plot
#' @param topTaxa if larger than zero: show the top N taxa most correlated to principal components as arrows in the PCoA
#' @param topMetadata if larger than zero, metadata provided and rda false: show the top N most significant numeric metadata as arrows and the top N most significant factor metadata as text in the PCoA
#' @param arrowFactor the length of taxon arrows (determined by scaled covariance) is multiplied with this factor
#' @param metadataFactor the length of numeric metadata arrows (determined by Pearson correlation) is multiplied with this factor
#' @param centroidFactor centroid positions are multiplied with this factor
#' @param pvals if true, p-values are represented as *: 3 for > 0.001, 2 for > 0.01 and 1 for > 0.05
#' @param taxonColor the color of the taxon arrows and text
#' @param metadataColor the color of the metadata arrows and text
#' @param xlim range shown on the x axis
#' @param ylim range shown on the y axis
#' @param permut number of permutations in envfit
#' @param pAdjMethod method for multiple testing correction supported by p.adjust for envfit p-values
#' @param qvalThreshold threshold on multiple-testing corrected envfit p-values
#' @param dimensions the principal components used for plotting, by default the first and second
#' @export
#'

seqPCoA<-function(data, tax_label=NULL, selected_taxa=c(), arrowColor= "Seagreen", 
                  centroidColor="", groupAttrib="", clusterAttrib="", clusterTaxon="", reference=NULL, dis="bray", rda=FALSE, scale=FALSE, 
                  doScree=FALSE, topTaxa=10, topMetadata=10, arrowFactor=0.0001, metadataFactor=1, centroidFactor=1, pvals=TRUE, 
                  taxonColor="brown", metadataColor="blue", xlim=c(-0.3,0.3), ylim=c(-0.3,0.3), permut=1000, pAdjMethod="BH", qvalThreshold=0.05, dimensions=c(1,2)){
  abundances <- data.frame(otu_table(data))
  metadata <- data.frame(sample_data(data))
  if(rda && is.null(metadata)){
    stop("Metadata are needed for RDA!")
  }
  
  if(!is.null(metadata) && scale){
    colums <- colnames(metadata)
    numerics <- unlist(lapply(metadata, is.numeric))
    numeric.metadata <- metadata[,numerics]
    catbin.metadata <- metadata[,!numerics]
    scaled.numeric.metadata=scale(numeric.metadata,center=TRUE, scale=TRUE)
    metadata=data.frame(scaled.numeric.metadata, catbin.metadata)
    colnames(metadata) <- colums
  }
  
  if(rda){
    pcoa.res=capscale(data.frame(t(abundances))~.,metadata,distance=dis, na.action = "na.omit")
    
  }else{
    
    # carry out PCoA
    pcoa.res=capscale(data.frame(t(abundances))~1,distance=dis, na.action = "na.omit")
    if(!is.null(metadata) && topMetadata>0){
      
      # carry out envfit
      ef=envfit(pcoa.res,metadata,perm=permut)
      
      # correct for multiple testing using code in http://www.davidzeleny.net/anadat-r/doku.php/en:indirect_ordination_suppl
      pvals.vectors=p.adjust(ef$vectors$pvals, method=pAdjMethod)
      pvals.factors=p.adjust(ef$factors$pvals, method=pAdjMethod)
      # sort p-values in ascending orders
      pvals.vectors.sorted=sort(pvals.vectors, index.return=TRUE)
      # keep sorting result for other vector output
      pvals.vectors=pvals.vectors.sorted$x
      # factors make only use of names, but not of any other result
      pvals.factors=sort(pvals.factors)
      indices.vectors=which(pvals.vectors<qvalThreshold)
      indices.factors=which(pvals.factors<qvalThreshold)
      print(paste(length(indices.vectors),"significant numeric metadata found, in order of significance:"))
      for(index in indices.vectors){
        print(names(pvals.vectors)[index])
      }
      print(paste(length(indices.factors),"significant categoric metadata found, in order of significance:"))
      for(index in indices.factors){
        print(names(pvals.factors)[index])
      }
      if(length(indices.vectors)>topMetadata){
        indices.vectors=indices.vectors[1:topMetadata]
      }
      if(length(indices.factors)>topMetadata){
        indices.factors=indices.factors[1:topMetadata]
      }
    } # do envfit
  } # not rda
  names(pvals.vectors) <- names(ef$vectors$r)
  if(doScree){
    barplot(pcoa.res$CA$eig, names.arg=c(1:length(pcoa.res$CA$eig)), main="Scree plot", xlab="Eigenvalue index", ylab="Eigenvalue")
  }
  
  # assign the right labels
  xlab=paste("PCoA",dimensions[1]," [",round(pcoa.res$CA$eig[dimensions[1]],2),"]",sep="")
  ylab=paste("PCoA",dimensions[2]," [",round(pcoa.res$CA$eig[dimensions[2]],2),"]",sep="")
  if(!is.null(metadata) && topMetadata > 0){
    main="PCoA with significant metadata"
  }else{
    main="PCoA"
  }
  # assign cluster memberships as shapes
  if(length(clusterAttrib)>1){
    pcoa_coords <- data.frame(pcoa.res$CA$u[,dimensions], Group=metadata[[groupAttrib]], Cluster=metadata[[clusterAttrib]])
    pcoa_plot <- ggplot() + geom_point(data=pcoa_coords, aes(x=MDS1, y=MDS2, color=Group, shape=Cluster)) +
      theme_minimal() + labs(x=xlab, y=ylab, main=main) + xlim(xlim) + ylim(ylim) 
  }
  else{
    pcoa_coords <- data.frame(pcoa.res$CA$u[,dimensions], Group=metadata[[groupAttrib]])
    pcoa_plot <- ggplot() + geom_point(data=pcoa_coords, aes(x=MDS1, y=MDS2, color=Group)) +
      theme_minimal() + labs(x=xlab, y=ylab, main=main) + xlim(xlim) + ylim(ylim) 
  }
  if (length(clusterTaxon)>0){
    merged_otus <- data.frame(matrix(ncol=length(sample_names(data)), nrow=length(unique(clusterTaxon))))
    for(i in 1:length(unique(clusterTaxon))){
      cluster = unique(clusterTaxon)[i]
      subdata <- subset_taxa(data, clusterTaxon == cluster)
      subotus <- colSums(data.frame(otu_table(subdata)))
      merged_otus[i,] <- subotus
    }
    Y=t(merged_otus)
    k <- ncol(pcoa.res$CA$u)
    n <- nrow(Y)
    # standardize eigen vectors
    points.stand <- scale(pcoa.res$CA$u[,dimensions])
    # covariance between taxa and selected principal components (standardized eigen vectors)
    S <- cov(Y, points.stand)
    corscores <- apply(abs(S),1,sum)
    all_permuts <- matrix(nrow=permut, ncol=length(corscores))
    # compute all covariances for permutations
    for (i in 1:permut){
      perm <- Y[sample(nrow(Y), replace=FALSE),]
      permS <- cov(perm, points.stand)
      permscores <- apply(abs(permS),1,sum)
      # the test assesses whether the permuted covariance is at least as extreme as the observed covariance
      # every time the permuted covariance is larger or equal, a success is added
      all_permuts[i,] <- permscores
    }
    # storage vector for p-values
    pvector <- rep(0, length(corscores))
    for (i in 1:length(pvector)){
      r <- sum(abs(all_permuts[,i]) >= abs(corscores[i]))
      pvector[i] <- (r+1)/permut
    }
    names(pvector) <- names(corscores)
    # scale S by the eigen values
    U <- S %*% diag((pcoa.res$CA$eig[dimensions]/(n-1))^(-0.5))
    colnames(U) <- colnames(pcoa.res$CA$u[,dimensions])
    # retrieve vector of OTU labels that match selected_taxa
    cluspoints <- data.frame(U)
    cluspoints$MDS1 <- U[,1]*arrowFactor
    cluspoints$MDS2 <- U[,2]*arrowFactor
    clus_labels <- paste("Cluster", unique(clusterTaxon))
    clus_arrows <- data.frame(cluspoints, labels=clus_labels, x0=rep(0, length(cluspoints$MDS1)), y0=rep(0, length(cluspoints$MDS1)))
  }

  endpoints <- list()
  if(!is.null(metadata) && topMetadata>0){
    if(length(indices.vectors)>0){
      # add arrows for numeric metadata
      ef.arrows=as.matrix(ef$vectors$arrows[pvals.vectors.sorted$ix[indices.vectors],dimensions])
      if(length(indices.vectors)==1){
        ef.arrows=t(ef.arrows)
      }
      lengths=ef$vectors$r[pvals.vectors.sorted$ix[indices.vectors]]
      # it is possible that topMetadata is larger than the metadata in the file
      # should correct to maximum possible topMetadata
      if (length(ef.arrows[,1]) < topMetadata){
        topMetadata <- length(ef.arrows[,1])
      }
      endpoints <- data.frame(ef.arrows)
      endpoints$MDS1 <- endpoints$MDS1*metadataFactor*lengths
      endpoints$MDS2 <- endpoints$MDS2*metadataFactor*lengths
      endpoints$labels <- rownames(endpoints)
      endpoints$x0 <- rep(0, topMetadata)
      endpoints$y0 <- rep(0, topMetadata)
    }
    if(length(indices.factors)>0){
      # the order of factors was altered, but since we match by name, this is not problematic
      sig.factors=names(indices.factors)
      # find centroids belonging to significant factors
      # centroid: mean or median dissimilarity of samples belonging to given level of a factor in PCoA
      # significance of centroid separation: TukeyHSD?
      sigpoints <- c()
      for (id in unique(ef$factors$var.id)){
        sigpoints <- as.vector(c(sigpoints, sort(unique(metadata[,id]))))
      }
      sigpoints <- data.frame(names=sigpoints, stringsAsFactors = FALSE)
      sigpoints$MDS1 <- ef$factors$centroids[,1]*centroidFactor
      sigpoints$MDS2 <- ef$factors$centroids[,2]*centroidFactor
      pcoa_plot <- pcoa_plot + geom_label(data=sigpoints, aes(x=sigpoints$MDS1, y=sigpoints$MDS2, label=sigpoints$names), color="Blue")
    } # significant factors found
  }
  # tax_arrows and endpoints dfs should be combined into 1 dataframe so geom_repel can prevent overlaps between labels
  arrow_df <- endpoints
  if (length(clusterTaxon) > 0){
    arrow_df <- rbind(clus_arrows, arrow_df)
  }
  pcoa_plot <- pcoa_plot + geom_segment(data=arrow_df, aes(x=x0, y=y0, 
                                                             xend=MDS1, yend=MDS2),arrow=arrow(), color=arrowColor) +
    ggrepel::geom_text_repel(data=arrow_df, aes(x=MDS1, y=MDS2, label=labels), force=3)
  return(pcoa_plot)
}


