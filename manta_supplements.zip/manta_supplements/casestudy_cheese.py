from manta.cluster import cluster_graph
from manta.reliability import perm_clusters
import networkx as nx
import pandas as pd


# replace this with correct file location
archive = ".."
filename = archive + "cheese//cheese.graphml"

graph = nx.read_graphml(filename)
graph = nx.to_undirected(graph)
# for a CoNet graph, we need to replace weight value with -1 and 1 (adjacency)
# negatively weighted edges (mutual exclusion) have 0 value or positive

for edge in graph.edges:
    if graph.edges[edge]['interactionType'] == 'copresence':
        graph.edges[edge]['weight'] = 1
    elif graph.edges[edge]['interactionType'] == 'mutualExclusion':
        graph.edges[edge]['weight'] = -1
    else:
        print('Wrong interaction type!' + graph.edges['interactionType'])

namedict = dict()
# igraph processing changes node IDs
for node in graph.nodes:
    namedict[node] = graph.nodes[node]['name'][1:]
    # namedict[node] = str(graph.nodes[node]['name'])
graph = nx.relabel_nodes(graph, namedict)
nx.set_node_attributes(graph, values=namedict, name='name')

# add taxonomy
tax = pd.read_table(archive + "cheese//tax.txt")
labels = ['Kingdom', 'Phylum', 'Class', 'Order', 'Family', 'Genus', 'Species']
for i in range(7):
    taxdict = dict.fromkeys([str(x) for x in tax.index])
    for j in range(len(taxdict)):
        name = tax.index[j]
        taxdict[str(name)] = tax.iloc[j, i]
    nx.set_node_attributes(graph, values=taxdict, name=labels[i])

results = cluster_graph(graph, limit=2, max_clusters=8, min_clusters=2,
                        iterations=20, min_cluster_size=0.1, subset=0.8,
                        edgescale=0.8, permutations=100, ratio=0.8, verbose=True)[0]
# perm_clusters(graph=results, limit=2, max_clusters=15,
#               min_clusters=2, iterations=20,
#               ratio=0.5,
#               partialperms=100, relperms=100,
#               error=0.1, verbose=True)

for node in results.nodes:
    for value in results.nodes[node]:
        results.nodes[node][value] = str(results.nodes[node][value])
        if value == 'name':
            results.nodes[node][value] = results.nodes[node][value][1:]
nx.write_graphml(results, archive + 'cheese//cheese_cluster.graphml')

