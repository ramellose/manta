"""
Parameters for the tested algorithms are compared in this file.
"""

import networkx as nx
import numpy as np
import sys
import matplotlib.pyplot as plt
from community.community_louvain import best_partition
import markov_clustering as mc
from networkx.algorithms.community import girvan_newman, kernighan_lin_bisection
from networkx.algorithms.cuts import conductance, cut_size
import pandas as pd
import seaborn as sns
from math import sqrt
from copy import deepcopy

archive = ".."
env_clusters = list()
for i in range(50):
    env = pd.read_csv((archive + "random2//growthrates_" + str(i+1) + ".csv"))
    diff = env['V1'] - env['V2']
    env_clusters.append(list())
    # 0.2 threshold arbitrary
    cluster1 = ['n' + str(x) for x in list(diff[diff > 0.3].index)]
    env_clusters[i].append(cluster1)
    cluster1 = ['n' + str(x) for x in list(diff[diff < -0.3].index)]
    env_clusters[i].append(cluster1)

networks = list()
positive_networks = list()
for i in range(50):
    filename = archive + "random2//graph_" + str(i+1) + ".graphml"
    network = nx.read_graphml(filename)
    networks.append(network)
    posnet = nx.Graph(((source, target, attr) for source, target, attr in
                       network.edges(data=True) if attr['weight'] > 0))
    positive_networks.append(posnet)


def cluster_comparison(posenv, alg_clusters):
    """
    Given two lists of clusters, this function
    identifies which clusters are the most similar to each other
    and returns the number of nodes that are assigned to the same or opposite
    cluster.
    Update: clusters with a size larger than 80% of the number of species are ignored.
    These tend to get high sensitivity and high separation.
    :param posenv: Clusters generated from environmental data
    :param alg_clusters: Clusters generated from algorithm
    :param manta: If clusters are generated with manta, the first cluster (fuzzy nodes) is ignored
    :return: Score tuple
    """
    # as described by Brohee et al 2006
    # for each cluster:
    # calculate the complex-wise sensitivity
    # calculate cluster-wise positive predictive value
    # compute weighted mean of both for all clusters
    # use these to calculate geometrical accuracy
    # geometrical mean of averaged Sn and PPV values
    # for better estimations of PPV,
    # it is important that nodes present in alg_clusters
    # but not in posenv are removed
    select_clusters = deepcopy(alg_clusters)
    large_cluster = False
    species = sum([len(item) for item in alg_clusters])
    for item in alg_clusters:
        if len(item) > (0.8 * species):
            sn = np.nan
            ppv = np.nan
            acc = np.nan
            sep = np.nan
            large_cluster = True
    if not large_cluster:
        posnodes = [item for sublist in posenv for item in sublist]
        for x in range(len(alg_clusters)):
            for node in alg_clusters[x]:
                if node not in posnodes:
                    select_clusters[x].remove(node)
        matches = np.zeros(shape=(len(posenv), len(select_clusters)))
        for i in range(len(posenv)):
            for j in range(len(select_clusters)):
                matches[i,j] = len(set(select_clusters[j]).intersection(posenv[i]))
        # calculate sensitivity
        sensitivity = matches.copy()
        for i in range(len(posenv)):
            for j in range(len(select_clusters)):
                sensitivity[i, j] /= len(posenv[i])
        # calculate maximal fraction of env cluster assigned to same cluster
        max_sensitivity = np.amax(sensitivity, axis=1)
        total = 0
        for i in range(len(posenv)):
            max_sensitivity[i] *= len(posenv[i])
            total += len(posenv[i])
        sn = np.sum(max_sensitivity) / total
        # calculate positive predictive value
        precision = matches.copy()
        for j in range(len(select_clusters)):
            if np.sum(precision[:,j]) != 0:
                precision[:,j] /= np.sum(precision[:,j])
            else:
                precision[:, j] = 0
        # calculate maximal fraction of cluster assigned to env cluster
        max_precision = np.amax(precision, axis=0)
        total = 0
        for i in range(len(select_clusters)):
            max_precision[i] *= len(select_clusters[i])
            total += len(select_clusters[i])
        ppv = np.sum(max_precision) / total
        acc = sqrt(sn * ppv)  # geometrical accuracy
        # separation; intersections between clusters
        # first part is equal to ppv
        # NOT CORRECT YET should be between 0 and 1
        colfreq = matches.copy()
        for j in range(len(select_clusters)):
            if np.sum(precision[:, j]) != 0:
                colfreq[:, j] /= np.sum(colfreq[:, j])
            else:
                colfreq[:, j] = 0
        rowfreq = matches.copy()
        for j in range(len(posenv)):
            if np.sum(rowfreq[j:, ]) != 0:
                rowfreq[j:, ] /= np.sum(rowfreq[j, :])
            else:
                rowfreq[j:, ] = 0
        separation = rowfreq * colfreq
        sepco = np.mean(np.sum(separation, axis=1))  # complex-wise separation
        sepcl = np.mean(np.sum(separation, axis=0))  # cluster-wise separation
        sep = sqrt(sepco * sepcl)  # geometrical accuracy
    return (sn, ppv, acc, sep)


def cluster_sparsity(graph, alg_clusters):
    """
    Defines clustering sparsity as used internally in manta for
    lists of cluster identities.
    :param graph: NetworkX graph
    :param alg_clusters: Clusters generated from algorithm
    :return: Sparsity score
    """
    cut_score = 1/len(graph.edges)
    sparsity = 0
    edges = list()
    for cluster_id in range(len(alg_clusters)):
        # get the set of edges that is NOT in either cluster
        node_ids = alg_clusters[cluster_id]
        cluster = graph.subgraph(node_ids)
        edges.extend(list(cluster.edges))
        # penalize for having negative edges inside cluster
        weights = nx.get_edge_attributes(cluster, 'weight')
        for x in weights:
            if weights[x] < 0:
                sparsity -= cut_score
            else:
                sparsity += cut_score
    all_edges = list(graph.edges)
    cuts = list()
    for edge in all_edges:
        if edge not in edges and (edge[1], edge[0]) not in edges:
            # problem with cluster edges having swapped orders
            cuts.append(edge)
    for edge in cuts:
        cut = graph[edge[0]][edge[1]]['weight']
        if cut > 0:
            sparsity -= cut_score
        else:
            sparsity += cut_score
    return sparsity


def cluster_quality(graph, alg_clusters):
    """
    Conductance
    for the cluster assignments.
    :param graph: NetworkX graph
    :param alg_clusters: Clusters generated from algorithm
    :param manta: If clusters are generated with manta, the first cluster (fuzzy nodes) is ignored
    :return: Score tuple
    """
    # conductance is only defined for 2 sets
    # more clusters than 2 can be defined
    # therefore, we calculate the mean conductance
    conductances = list()
    for cluster in range(len(alg_clusters)):
        if (len(alg_clusters[cluster]) != 100) and (len(alg_clusters[cluster]) != 1):
            # first check if there are even edges between clusters
            T = set(graph) - set(alg_clusters[cluster])
            num_cut_edges = cut_size(graph, alg_clusters[cluster], T, weight=None)
            if num_cut_edges != 0:
                conductances.append(conductance(graph, alg_clusters[cluster]))
            else:
                conductances.append(0)
        else:
            conductances.append(0)
    results = np.mean(conductances)
    return results
# evaluate manta_cluster parameters on the Klemms dataset
# choice of parameters: min_clusters and max_clusters
# edgescale for fuzzy clustering
# convergence is rapid, so limit and iterations should not matter
# however, the number of clusters may affect to what extent
# the k-means algorithm separates central nodes


def plot_results(stats, data, varname, filename, outloc, nan=False, ypos=0.12):
    """
    Given a file of results, generates the appropriate figure.
    :param stats: Pandas dataframe with results
    :param data: List of lists of cluster assignments
    :param varname: Name of variable that is adjusted
    :param filename: Name for saving image
    :param outloc: Location for saving image
    :param nan: If true, plot # of missing vals. Otherwise, plot avg cluster size.
    :return:
    """
    figure1 = sns.violinplot(x=varname, y="Sep", data=stats, color="gray")
    every_nth = 2
    for n, label in enumerate(figure1.xaxis.get_ticklabels()):
        if n % every_nth != 0:
            label.set_visible(False)# plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    # count number of assignments per var
    textrange = range(-3, len(set(stats[varname]))*10, 10)
    measurements = list(set(stats[varname]))
    for i in range(len(measurements)):
        measure = measurements[i]
        if nan:
            substats = stats[stats[varname] == measure]
            missingno = 50 - substats['Sn'].isnull().values.sum()
        else:
            subdata = data[i]
            no_assignments = list()
            for clusters in subdata:
                total_assignments = 0
                for cluster in clusters:
                    total_assignments += len(cluster)
                no_assignments.append(total_assignments)
            missingno = np.median(no_assignments)
        x = textrange[i] / 10
        if np.max(stats['Sep']) > 0.95:
            y = np.max(stats['Sep']) + 0.15
        else:
            y = np.max(stats['Sep']) + ypos
        figure1.axes.text(s=str(int(missingno)), x=x, y=y, size=10)
    plt.savefig(outloc + filename, format="pdf", papertype='a4', dpi=1200)
    # allows for visual inspection of plots
    plt.clf()


archive = ".."
replicates = 50
sourcename = archive + "random2//graph_"
networks = list()
positive_networks = list()

for i in range(replicates):
    filename = sourcename + str(i + 1) + ".graphml"
    network = nx.read_graphml(filename)
    # shift edges to positive range
    # weights = nx.get_edge_attributes(network, 'weight')
    # minval = np.min(list(weights.values()))
    # for key in weights:
    #    weights[key] -= minval
    # nx.set_edge_attributes(network, weights, 'weight')
    #
    networks.append(network)
    posnet = nx.Graph(((source, target, attr) for source, target, attr in
                       network.edges(data=True) if attr['weight'] > 0))
    positive_networks.append(posnet)

resolution = list()
resolution_positive = list()
resolution_range = list(range(1, 21))
for i in range(20):
    louvain_clusters = list()
    louvain_clusters_positive = list()
    for j in range(50):
        # Louvain community detection
        network = networks[j]
        posnet = positive_networks[j]
        unweighted_graph = network.copy()
        for u, v, d in unweighted_graph.edges(data=True):
            d['weight'] = 1
        clusters = best_partition(unweighted_graph, resolution=resolution_range[i])
        louvain_clusters.append(list())
        for k in range(len(set(clusters.values()))):
            louvain_clusters[j].append(list())
            for node in clusters:
                if clusters[node] == list(set(clusters.values()))[k]:
                    louvain_clusters[j][k].append(node)
        clusters = best_partition(posnet, resolution=resolution_range[i])
        louvain_clusters_positive.append(list())
        for k in range(len(set(clusters.values()))):
            louvain_clusters_positive[j].append(list())
            for node in clusters:
                if clusters[node] == list(set(clusters.values()))[k]:
                    louvain_clusters_positive[j][k].append(node)
    resolution.append(louvain_clusters)
    resolution_positive.append(louvain_clusters_positive)

expansion = list()
expansion_positive = list()
for i in range(2, 21):
    mcl_clusters = list()
    mcl_clusters_positive = list()
    for j in range(50):
        # MCL
        network = networks[j]
        posnet = positive_networks[j]
        mcl_clusters.append(list())
        matrix = nx.to_scipy_sparse_matrix(network)
        matrix[matrix == -1] = 1
        result = mc.run_mcl(matrix, expansion=i, inflation=3)
        clusters = mc.get_clusters(result)
        for k in range(len(clusters)):
            mcl_clusters[j].append(list(clusters[k]))
        mcl_clusters_positive.append(list())
        matrix = nx.to_scipy_sparse_matrix(posnet)
        result = mc.run_mcl(matrix, expansion=i)
        clusters = mc.get_clusters(result)
        for k in range(len(clusters)):
            mcl_clusters_positive[j].append(list(clusters[k]))
    expansion.append(mcl_clusters)
    expansion_positive.append(mcl_clusters_positive)

inflation = list()
inflation_positive = list()
for i in range(2, 21):
    mcl_clusters = list()
    mcl_clusters_positive = list()
    for j in range(50):
        # MCL
        network = networks[j]
        posnet = positive_networks[j]
        mcl_clusters.append(list())
        matrix = nx.to_scipy_sparse_matrix(network)
        matrix[matrix == -1] = 1
        result = mc.run_mcl(matrix, inflation=i)
        clusters = mc.get_clusters(result)
        for k in range(len(clusters)):
            mcl_clusters[j].append(list(clusters[k]))
        mcl_clusters_positive.append(list())
        matrix = nx.to_scipy_sparse_matrix(posnet)
        result = mc.run_mcl(matrix, inflation=i)
        clusters = mc.get_clusters(result)
        for k in range(len(clusters)):
            mcl_clusters_positive[j].append(list(clusters[k]))
    inflation.append(mcl_clusters)
    inflation_positive.append(mcl_clusters_positive)

iteration = list()
iteration_positive = list()
for i in range(2, 21):
    kernighan_clusters = list()
    kernighan_clusters_positive = list()
    for j in range(50):
        # kernighan-lin
        network = networks[j]
        posnet = positive_networks[j]
        kernighan_clusters.append(list())
        clusters = kernighan_lin_bisection(network, max_iter=i)
        for k in range(len(clusters)):
            kernighan_clusters[j].append((clusters[k]))
        kernighan_clusters_positive.append(list())
        clusters = kernighan_lin_bisection(posnet, max_iter=i)
        for k in range(len(clusters)):
            kernighan_clusters_positive[j].append(list(clusters[k]))
    iteration.append(kernighan_clusters)
    iteration_positive.append(kernighan_clusters_positive)

# snippet below converts MCL outcome to proper species names
for iter in range(50):
    nodedict = dict.fromkeys(networks[iter].nodes)
    i = 0
    for key in list(networks[iter].nodes):
        nodedict[key] = i
        i +=1
    nodedict = {v: k for k, v in nodedict.items()}
    for param_iter in range(19):
        for cluster in range(len(expansion[param_iter][iter])):
            for node in range(len(expansion[param_iter][iter][cluster])):
                expansion[param_iter][iter][cluster][node] = \
                    nodedict[expansion[param_iter][iter][cluster][node]]
        for cluster in range(len(inflation[param_iter][iter])):
            for node in range(len(inflation[param_iter][iter][cluster])):
                inflation[param_iter][iter][cluster][node] = \
                    nodedict[inflation[param_iter][iter][cluster][node]]

for iter in range(50):
    nodedict = dict.fromkeys(positive_networks[iter].nodes)
    i = 0
    for key in list(positive_networks[iter].nodes):
        nodedict[key] = i
        i +=1
    nodedict = {v: k for k, v in nodedict.items()}
    for param_iter in range(19):
        for cluster in range(len(expansion_positive[param_iter][iter])):
            for node in range(len(expansion_positive[param_iter][iter][cluster])):
                expansion_positive[param_iter][iter][cluster][node] = \
                    nodedict[expansion_positive[param_iter][iter][cluster][node]]
        for cluster in range(len(inflation_positive[param_iter][iter])):
            for node in range(len(inflation_positive[param_iter][iter][cluster])):
                inflation_positive[param_iter][iter][cluster][node] = \
                    nodedict[inflation_positive[param_iter][iter][cluster][node]]

# louvain params
#resolution
#resolution_positive
louvain_resolution = pd.DataFrame(np.zeros(shape=(20*50, 7)))
louvain_resolution.columns = ['Resolution', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
louvain_positive_resolution = pd.DataFrame(np.zeros(shape=(20*50, 7)))
louvain_positive_resolution.columns = ['Resolution', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
k = 0
for j in range(20):
    parameter = list(range(1, 21))[j]/10
    for i in range(50):
        louvain_resolution.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], resolution[j][i])
        louvain_resolution.iloc[k, 1] = results[0]
        louvain_resolution.iloc[k, 2] = results[1]
        louvain_resolution.iloc[k, 3] = results[2]
        louvain_resolution.iloc[k, 4] = results[3]
        louvain_resolution.iloc[k, 5] = cluster_sparsity(networks[i], resolution[j][i])
        results = cluster_quality(networks[i], resolution[j][i])
        louvain_resolution.iloc[k, 6] = results
        louvain_positive_resolution.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], resolution_positive[j][i])
        louvain_positive_resolution.iloc[k, 1] = results[0]
        louvain_positive_resolution.iloc[k, 2] = results[1]
        louvain_positive_resolution.iloc[k, 3] = results[2]
        louvain_positive_resolution.iloc[k, 4] = results[3]
        louvain_positive_resolution.iloc[k, 5] = cluster_sparsity(positive_networks[i], resolution_positive[j][i])
        results = cluster_quality(positive_networks[i], resolution_positive[j][i])
        louvain_positive_resolution.iloc[k, 6] = results
        k += 1

# mcl params
#expansion
#expansion_positive
#inflation
#inflation_positive
mcl_expansion = pd.DataFrame(np.zeros(shape=(19*50, 7)))
mcl_expansion.columns = ['Expansion', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
mcl_positive_expansion = pd.DataFrame(np.zeros(shape=(19*50, 7)))
mcl_positive_expansion.columns = ['Expansion', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
mcl_inflation = pd.DataFrame(np.zeros(shape=(19*50, 7)))
mcl_inflation.columns = ['Inflation', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
mcl_positive_inflation = pd.DataFrame(np.zeros(shape=(19*50, 7)))
mcl_positive_inflation.columns = ['Inflation', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
k = 0
for j in range(19):
    parameter = list(range(2,21))[j]
    for i in range(50):
        mcl_expansion.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], expansion[j][i])
        mcl_expansion.iloc[k, 1] = results[0]
        mcl_expansion.iloc[k, 2] = results[1]
        mcl_expansion.iloc[k, 3] = results[2]
        mcl_expansion.iloc[k, 4] = results[3]
        mcl_expansion.iloc[k, 5] = cluster_sparsity(networks[i], expansion[j][i])
        results = cluster_quality(networks[i], expansion[j][i])
        mcl_expansion.iloc[k, 6] = results
        mcl_positive_expansion.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], expansion_positive[j][i])
        mcl_positive_expansion.iloc[k, 1] = results[0]
        mcl_positive_expansion.iloc[k, 2] = results[1]
        mcl_positive_expansion.iloc[k, 3] = results[2]
        mcl_positive_expansion.iloc[k, 4] = results[3]
        mcl_positive_expansion.iloc[k, 5] = cluster_sparsity(positive_networks[i], expansion_positive[j][i])
        results = cluster_quality(positive_networks[i], expansion_positive[j][i])
        mcl_positive_expansion.iloc[k, 6] = results
        mcl_inflation.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], inflation[j][i])
        mcl_inflation.iloc[k, 1] = results[0]
        mcl_inflation.iloc[k, 2] = results[1]
        mcl_inflation.iloc[k, 3] = results[2]
        mcl_inflation.iloc[k, 4] = results[3]
        mcl_inflation.iloc[k, 5] = cluster_sparsity(networks[i], inflation[j][i])
        results = cluster_quality(networks[i], inflation[j][i])
        mcl_inflation.iloc[k, 6] = results
        mcl_positive_inflation.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], inflation_positive[j][i])
        mcl_positive_inflation.iloc[k, 1] = results[0]
        mcl_positive_inflation.iloc[k, 2] = results[1]
        mcl_positive_inflation.iloc[k, 3] = results[2]
        mcl_positive_inflation.iloc[k, 4] = results[3]
        mcl_positive_inflation.iloc[k, 5] = cluster_sparsity(positive_networks[i], inflation_positive[j][i])
        results = cluster_quality(positive_networks[i], inflation_positive[j][i])
        mcl_positive_inflation.iloc[k, 6] = results
        k += 1

# kernighan-lin params
#iteration
#iteration_positive
kernighan_iteration = pd.DataFrame(np.zeros(shape=(19*50, 7)))
kernighan_iteration.columns = ['Iteration', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
kernighan_positive_iteration = pd.DataFrame(np.zeros(shape=(19*50, 7)))
kernighan_positive_iteration.columns = ['Iteration', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
k = 0
for j in range(19):
    parameter = list(range(2,21))[j]
    for i in range(50):
        kernighan_iteration.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], iteration[j][i])
        kernighan_iteration.iloc[k, 1] = results[0]
        kernighan_iteration.iloc[k, 2] = results[1]
        kernighan_iteration.iloc[k, 3] = results[2]
        kernighan_iteration.iloc[k, 4] = results[3]
        kernighan_iteration.iloc[k, 5] = cluster_sparsity(networks[i], iteration[j][i])
        results = cluster_quality(networks[i], iteration[j][i])
        kernighan_iteration.iloc[k, 6] = results
        kernighan_positive_iteration.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], iteration_positive[j][i])
        kernighan_positive_iteration.iloc[k, 1] = results[0]
        kernighan_positive_iteration.iloc[k, 2] = results[1]
        kernighan_positive_iteration.iloc[k, 3] = results[2]
        kernighan_positive_iteration.iloc[k, 4] = results[3]
        kernighan_positive_iteration.iloc[k, 5] = cluster_sparsity(positive_networks[i], iteration_positive[j][i])
        results = cluster_quality(positive_networks[i], iteration_positive[j][i])
        kernighan_positive_iteration.iloc[k, 6] = results
        k += 1

# girvan-newman doesn't have parameters
#louvain_resolution
#louvain_positive_resolution
#mcl_expansion
#mcl_positive_expansion
#mcl_inflation
#mcl_positive_inflation
#kernighan_iteration
#kernighan_positive_iteration
outloc = archive + "params//"

louvain_resolution.to_csv(outloc+"louvain_resolution.csv")
louvain_positive_resolution.to_csv(outloc+"louvain_positive_resolution.csv")
mcl_expansion.to_csv(outloc+"mcl_expansion.csv")
mcl_inflation.to_csv(outloc+"mcl_inflation.csv")
mcl_positive_expansion.to_csv(outloc+"mcl_positive_expansion.csv")
mcl_positive_inflation.to_csv(outloc+"mcl_positive_inflation.csv")
kernighan_iteration.to_csv(outloc+"kernighan_iteration.csv")
kernighan_positive_iteration.to_csv(outloc+"kernighan_positive_iteration.csv")

louvain_resolution = pd.read_csv(outloc+"louvain_resolution.csv")
louvain_positive_resolution = pd.read_csv(outloc+"louvain_positive_resolution.csv")
mcl_expansion = pd.read_csv(outloc+"mcl_expansion.csv")
mcl_inflation = pd.read_csv(outloc+"mcl_inflation.csv")
mcl_positive_expansion = pd.read_csv(outloc+"mcl_positive_expansion.csv")
mcl_positive_inflation = pd.read_csv(outloc+"mcl_positive_inflation.csv")
kernighan_iteration = pd.read_csv(outloc+"kernighan_iteration.csv")
kernighan_positive_iteration = pd.read_csv(outloc+"kernighan_positive_iteration.csv")

sns.set(style="whitegrid", palette="cubehelix")

# if nan is true, counts number of missing assignments
# if nan is false (default), gives median cluster size
plot_results(stats=louvain_resolution, data=resolution, nan=True, ypos=0.06,
             varname="Resolution", filename="louvain_resolution.pdf", outloc=outloc)
plot_results(stats=louvain_positive_resolution, data=resolution_positive, nan=True,
             varname="Resolution", filename="louvain_positive_resolution.pdf", outloc=outloc)

plot_results(stats=mcl_inflation, data=inflation, nan=True, ypos=0.04,
             varname="Inflation", filename="mcl_inflation.pdf", outloc=outloc)
plot_results(stats=mcl_positive_inflation, data=inflation_positive, nan=True, ypos=0.04,
             varname="Inflation", filename="mcl_positive_inflation.pdf", outloc=outloc)

plot_results(stats=mcl_expansion, data=expansion, nan=True,
             varname="Expansion", filename="mcl_expansion.pdf", outloc=outloc)
plot_results(stats=mcl_positive_expansion, data=expansion_positive, nan=True,
             varname="Expansion", filename="mcl_positive_expansion.pdf", outloc=outloc)

plot_results(stats=kernighan_iteration, data=iteration, nan=True, ypos=0.06,
             varname="Iteration", filename="kernighan_iteration.pdf", outloc=outloc)
plot_results(stats=kernighan_positive_iteration, data=iteration_positive, nan=True, ypos=0.08,
             varname="Iteration", filename="kernighan_positive_iteration.pdf", outloc=outloc)
