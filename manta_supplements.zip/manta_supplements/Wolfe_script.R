setwd("cheese")
library(phyloseq)
library(igraph)
library(viridis)
library(ggplot2)
library(Hmisc)

prevFilter = function(phy, prev){
  prev0 = apply(X = otu_table(phy),
                MARGIN = ifelse(taxa_are_rows(phy), yes = 1, no = 2),
                FUN = function(x){sum(x > 0)})
  prevalenceThreshold = prev * nsamples(phy)
  nonrares = prune_taxa((prev0 > prevalenceThreshold), phy)
  rares = prune_taxa((prev0 < prevalenceThreshold), phy)
  rares = merge_taxa(rares, taxa_names(rares))
  otus = data.frame(otu_table(nonrares))
  otus = rbind(otus, data.frame(otu_table(rares)))
  tax = data.frame(tax_table(nonrares), stringsAsFactors = FALSE)
  tax = rbind(tax, c("Bacteria", rep(NA, 6)))
  rownames(tax)[length(rownames(tax))] = taxa_names(rares)
  colnames(otus) <- rownames(sample_data(phy))  # checked manually if this is correct; data.frame adds an X for every name
  newphy = phyloseq(otu_table(otus, taxa_are_rows = TRUE), sample_data(phy), tax_table(as.matrix(tax)))
  return(newphy)
}

phylo <- import_biom("../../11488/BIOM/47198/otu_table.biom")

meta <- read.csv("../../11488/mapping_files/47198_mapping_file.txt", sep="\t")
rownames(meta) <- meta$X.SampleID
meta <- meta[,c(21, 32, 39)]
sample_data(phylo) <- meta

# first remove samples with extremely low counts
lowcounts <- sample_sums(phylo)
names(lowcounts) <- sample_names(phylo)
lowcounts <- lowcounts[sample_sums(phylo) < 10000]
phylo <- prune_samples((!sample_names(phylo) %in% names(lowcounts)), phylo)
# phylo <- tax_glom(phylo, taxrank="Rank6", NArm = FALSE)
set.seed(7)
# rarefy to even depth
phylo <- rarefy_even_depth(phylo)

# 20% prevalence filter
phylo <- prevFilter(phylo, 0.2)

gp_bray_pcoa = ordinate(phylo, "PCoA", "bray")
plot_ordination(phylo, gp_bray_pcoa, "samples", color="rindtype") + theme_minimal() + 
  xlab("PCoA 1 [26.4%]") + ylab("PCoA 2 [14.6%]") + 
  labs(color="Rind type") + scale_color_viridis_d() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), 
        axis.line = element_line(colour = "black"), axis.text.x = element_blank(), axis.ticks = element_blank(), axis.text.y = element_blank()) + coord_flip()

saveRDS(phylo, "cheese_phyloseq.rds")
phylo <- readRDS("cheese_phyloseq.rds")
otus <- data.frame(otu_table(phylo))
tax <- data.frame(tax_table(phylo))
# need to adjust colnames for CoNet
# if conet: 
rownames(otus) <- paste("c", rownames(otus), sep="")
rownames(tax) <- paste("c", rownames(tax), sep="")
cat("test \t", file = 'tax.txt') 
write.table(tax, file = 'tax.txt', append = TRUE, quote=FALSE, sep="\t")
cat("test \t", file = 'otu.txt') 
write.table(otus, file = 'otu.txt', append = TRUE, quote=FALSE, sep="\t")
# write.table(tax, "tax.txt", quote=FALSE, sep="\t")
# write.table(otus, "otu.txt", quote=FALSE, sep="\t")

# correlate cluster to moisture
testdata <- data.frame(sample_data(phylo))
graph <- read_graph("cheese_cluster.graphml", format="graphml")
k = 1
pvals <- c()
corrs <- c()
names <- c()
colors <- c()

# correlate by phylum; network phylum? 
# correlate by cluster
phyla <- c("p__Actinobacteria", "p__Bacteroidetes", "p__Firmicutes", "p__Proteobacteria")
for (item in phyla){
  filter_phylo <- subset_taxa(phylo, Rank2==item)
  otu <- colSums(data.frame(otu_table(filter_phylo)))
  testdata$OTU <- otu
  results <- rcorr(testdata$OTU, testdata$moisture, type="spearman")
  corrs[k] <- results$r[2,1]
  # pvals[k] <- p.adjust(results$P[2,1], method="BH", n=length(phyla))
  pvals[k] <- results$P[2,1]
  names[k] <- item
  if (item == 'p__Actinobacteria'){
    colors[k] <- 'Actinobacteria'
  }
  else {
    colors[k] <- 'Other'
  }
  k = k + 1
}

# correlate by cluster
clusters <- c(0, 1, 2, 3)
for (item in clusters){
  ids <- c()
  for (node in V(graph)){
    cluster <- vertex_attr(graph, 'cluster', node)
    if (as.integer(cluster) == item){
      ids <- c(ids, vertex_attr(graph, 'name', node))
    }
  }
  filter_phylo <- prune_taxa(ids, phylo)
  otu <- colSums(data.frame(otu_table(filter_phylo)))
  testdata$OTU <- otu
  results <- rcorr(testdata$OTU, testdata$moisture, type="spearman")
  corrs[k] <- results$r[2,1]
  # pvals[k] <- p.adjust(results$P[2,1], method="BH", n=length(phyla))
  pvals[k] <- results$P[2,1]
  names[k] <- paste('Cluster', item)
  colors[k] <- 'Other'
  k = k + 1
}

# correlate by Actinobacteria cluster
clusters <- c(0, 1, 2, 3)
for (item in clusters){
  ids <- c()
  for (node in V(graph)){
    cluster <- vertex_attr(graph, 'cluster', node)
    phylum <- vertex_attr(graph, 'Phylum', node)
    if (as.integer(cluster) == item && phylum == 'p__Actinobacteria'){
      ids <- c(ids, vertex_attr(graph, 'name', node))
    }
  }
  filter_phylo <- prune_taxa(ids, phylo)
  otu <- colSums(data.frame(otu_table(filter_phylo)))
  testdata$OTU <- otu
  results <- rcorr(testdata$OTU, testdata$moisture, type="spearman")
  corrs[k] <- results$r[2,1]
  # pvals[k] <- p.adjust(results$P[2,1], method="BH", n=length(clusters)*length(phyla))
  pvals[k] <- results$P[2,1]
  names[k] <- paste('Actinobacteria cluster', item)
  colors[k] <- 'Actinobacteria'
  k = k + 1
}

results <- data.frame(matrix(ncol=4,nrow=length(names)))
colnames(results) <- c("Taxa", "Spearman correlation", "Model p-value", "Color")
results$Taxa <- names
results$`Spearman correlation` <- corrs
pvals <- p.adjust(pvals, method="BH")
results$`Model p-value` <- pvals
results$Color <- colors

results$Taxa <- c('Actinobacteria', 'Bacteroidetes', 'Firmicutes', 'Proteobacteria', results$Taxa[5:12])
results$Taxa <- ordered(results$Taxa, levels=rev(results$Taxa))
ggplot(data=results) + geom_col(aes(x=results$Taxa, y=results$`Spearman correlation`, fill=results$Color)) + coord_flip() + 
  theme_minimal() +labs(x="", y="Spearman correlation to moisture") + theme(legend.position="none") + scale_fill_manual(values=c("darkcyan", "darkgrey")) +
  theme( panel.grid.minor = element_blank(), panel.background = element_blank())

# get abundance plot per cluster

