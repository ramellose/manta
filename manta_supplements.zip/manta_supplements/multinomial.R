# This file contains the code required for generating permuted graphs. 
# The filepaths have been adjusted and may not be entirely correct;
# please fix these for your own system. 

setwd("..")

library(SpiecEasi)
library(igraph)
library(Hmisc)
library(WGCNA)

sims <- list(readRDS("random2/50envreplicates_random2.rds"),
             readRDS("random3/50envreplicates_random3.rds"), 
             readRDS("fabia2/fabia2clusters.rds"),
             readRDS("fabia3/fabia3clusters.rds"))
graphnames <- c("random2/graph_multinomial_",
                "random3/graph_multinomial_",
                "fabia2/graph_multinomial_",
                "fabia3/graph_multinomial_")
wgcnanames <- c("random2/",
                "random3/",
                "fabia2/",
                "fabia3/")

permsims = list()
sizes <- seq(0, 10000, by=1000)
c = 1
for (c in 1:1){
  # write all matrices to format that can be read by networkx
  for (j in 1:1){
    alldata = sims[[j]]
    for (s in 1:50){
      data <- alldata[[s]]
      # reinfer WGCNA and Spearman networks
      ######## multinomial noise strategy
      # 
      # first scale data and round 
      # same as in https://microbiomejournal.biomedcentral.com/articles/10.1186/s40168-018-0496-2#Sec8
      data <- data * 1000
      data <- round(data, digits=0)
      # fabia can give negative values; set these to 0
      data[data <0] <- 0
      # then add increasing multinomial noise
      # size is scaled - 0 to 1000
      probs <- scale(data, center=FALSE, scale=colSums(data))
      if (c > 1){
        size <- sizes[c]
        # distribution is uniform
      }
      size = 1500
      for (i in 1:length(colnames(data))){
        prob <- probs[,i]
        data[,i] <- rmultinom(1, size, prob)
      }
      result <- rcorr(t(data))
      graph <- result$r
      graph[is.na(graph)] <- 0
      graph[result$P > 0.05] <- 0
      for (i in 1:100){
        for (k in 1:100){
          if (i == k){
            graph[i,i] <- 0
          }
        }
      }
    
    # remove nodes with only 0s
    rem_nodes <- colSums(graph != 0)
    rem_nodes <- rem_nodes != 0
    graph <- graph[rem_nodes, rem_nodes]
    graph <- graph_from_adjacency_matrix(graph, weighted=TRUE, mode=c("undirected"))
    #name <- paste(graphnames[j], c, "_", s, ".graphml", sep="")
    name <- paste(graphnames[j], c, "_",  s, ".graphml", sep="")
    write_graph(graph, file=name, format="graphml")
    
    # WGCNA
    dynamicMods <- blockwiseModules(t(data), networkType = "signed", TOMType="signed")
    dynamicMods <- dynamicMods$colors
    # generate dictionary of ints
    dynamicMods[dynamicMods == "grey"] <- 0
    for (b in 1:length(unique(dynamicMods))){
      color <- unique(dynamicMods)[[b]]
      if (color != 0){
        dynamicMods[dynamicMods == color] <- b
      }
    }
    #write.csv(dynamicMods, paste(wgcnanames[j], s, "_wgcna_signed_multinom_", c, ".csv", sep=""))
    write.csv(dynamicMods, paste(wgcnanames[j],c, "_",  s, "_wgcna_signed_multinomial.csv", sep=""))
    dynamicMods <- blockwiseModules(t(data), networkType = "unsigned", TOMType="unsigned")
    dynamicMods <- dynamicMods$colors
    # generate dictionary of ints
    dynamicMods[dynamicMods == "grey"] <- 0
    for (b in 1:length(unique(dynamicMods))){
      color <- unique(dynamicMods)[[b]]
      if (color != 0){
        dynamicMods[dynamicMods == color] <- b
      }
    }
    #write.csv(dynamicMods, paste(wgcnanames[j], s, "_wgcna_unsigned_multinom_", c, ".csv", sep=""))
    write.csv(dynamicMods, paste(wgcnanames[j], c, "_", s, "_wgcna_unsigned_multinomial.csv", sep=""))
    }
  }
}
