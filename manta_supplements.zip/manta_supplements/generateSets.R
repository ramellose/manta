#' @title Generate multiple datasets
#' @description Generate a list of list of datasets with n replicates for x datapoints.
#' @details Calls on the envGrowthChanges, generateDataSet and glv functions from seqtime to generate datasets compatible with other functions.
#'
#' @param n number of replicates; one interaction matrix generated per replicate
#' @param species number of replicates
#' @param samples number of samples
#' @param name filename of output dataset
#' @param strength strength of environmental effect
#' @param mode random or klemm-eguiluz interaction matrix
#'
#' @return Returns list of datasets and saves .rds file of list
#' @export
generateSets = function(n, species, samples, name, strength, conditions, env.factors, mode='klemm'){
  envlist <- list()
  klemms <- list()
  for (i in 1:n){
    klemms[[i]] <- seqtime::generateA(N=species, type=mode, c=0.05, pep=20)
  }
  saveRDS(klemms, paste(name, "-interactions.rds", sep=""))
  data <- list()
  env <- list()
  for (j in 1:n){
    env1 = envGrowthChanges(species=species,  env.factors=env.factors, conditions=conditions, strength=strength)
    env[[j]] <- env1
    subset = seqtime:::generateDataSet(samples, klemms[[j]], env.matrix = env1[[3]], perturb.count = rep(samples/conditions, conditions))
    data[[j]] <- subset
    envname <- paste(name, "_envfactors.rds", sep="")
    saveRDS(env, envname)
  }
  saveRDS(data, paste(name, ".rds", sep=""))
  return(data)
}

#' @title Generate multiple datasets
#' @description Generate a list of list of datasets with n replicates for x datapoints.
#' @details Calls on the envGrowthChanges, generateDataSet and glv functions from seqtime to generate datasets compatible with other functions.
#' The function is identical to the one above except it calls a slightly different envGrowthChanges function.
#'
#' @param n number of replicates; one interaction matrix generated per replicate
#' @param species number of replicates
#' @param samples number of samples
#' @param name filename of output dataset
#' @param strength strength of environmental effect
#' @param mode random or klemm-eguiluz interaction matrix
#'
#' @return Returns list of datasets and saves .rds file of list
#' @export
generate3Sets = function(n, species, samples, name, strength, conditions, env.factors, mode='klemm'){
  envlist <- list()
  klemms <- list()
  for (i in 1:n){
    klemms[[i]] <- seqtime::generateA(N=species, type=mode, c=0.05, pep=20)
  }
  saveRDS(klemms, paste(name, "-interactions.rds", sep=""))
  data <- list()
  env <- list()
  for (j in 1:n){
    env1 = env3GrowthChanges(species=species,  env.factors=env.factors, conditions=conditions, strength=strength)
    env[[j]] <- env1
    subset = seqtime:::generateDataSet(samples, klemms[[j]], env.matrix = env1[[3]], perturb.count = rep(samples/conditions, conditions))
    data[[j]] <- subset
    envname <- paste(name, "_envfactors.rds", sep="")
    saveRDS(env, envname)
  }
  saveRDS(data, paste(name, ".rds", sep=""))
  return(data)
}

