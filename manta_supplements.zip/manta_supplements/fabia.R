library(fabia)
setwd("fabia2")
# the function below was used to base our own function on. 
# With the function below, the exact location of the clusters is random. 
# We need this location to have true positives
res <- makeFabiaDataBlocksPos(n=100, l=100, p=4, f1=25, f2=25, of1=25, of2=25, sd_noise=2, sd_z_noise=0.2, mean_z=3, sd_z=1, sd_l_noise=0.2, mean_l = 3, sd_l=0)
data <- res$X
heatmap(data, Rowv=NA)


# dat <- makeFabiaDataBlocks(n = 100,l= 50,p = 3,f1 = 5,f2 = 5, of1 = 5,of2 = 10,sd_noise = 3.0,sd_z_noise = 0.2,mean_z = 2.0, sd_z = 1.0,sd_l_noise = 0.2,mean_l = 3.0,sd_l = 1.0)

# fabia source code
alldata = list()
n=100
l=80
p=2
f1=40
f2=40
of1=40
of2=40
sd_noise=2
sd_z_noise=0.2
mean_z=3
sd_z=1
sd_l_noise=3
mean_l=3
sd_l=1
for (k in 1:50){
  za <- rep(f1, p)
  la <- rep(f1, p)
  ZC <- list()
  LC <- list()
  X <- matrix(rnorm(l * n, mean = 0, sd = sd_noise), n, l)
  Y <- matrix(0, n, l)
  rownames(X) <- rownames(X, do.NULL = FALSE, prefix = "gene")
  colnames(X) <- colnames(X, do.NULL = FALSE, prefix = "sample")
  rownames(Y) <- rownames(X)
  colnames(Y) <- colnames(X)
  for (i in 1:p) {
    zj <- rnorm(l, mean = 0, sd = sd_z_noise)
    z0 <- as.vector(rep(0, l))
    # tf <- floor(runif(1) * (l - za[i]))
    # zf <- tf:(tf + za[i] - 1)
    # in the original Fabia code, the start of the biclustering is selected randomly
    # hence, the clusters overlap and a lot of noise appears
    # here, I set the bicluster boundaries so they make more sense
    startpos = 1 + (f1 * (i-1))
    endpos = f1 * i - 10  # 10 genes are completely random
    zf <- seq(startpos, endpos)
    ZC[[i]] <- zf
    z1 <- rnorm((length(zf)), mean = mean_z, sd = sd_z)
    zj[zf] <- z1
    z0[zf] <- z1
    lj <- rnorm(n, mean = 0, sd = sd_l_noise)
    l0 <- as.vector(rep(0, n))
    # uf <- floor(runif(1) * (n - la[i]))
    # lf <- uf:(uf + la[i] - 1)
    lf <- seq(startpos, endpos)
    LC[[i]] <- lf
    l1 <- rnorm((length(lf)), mean = mean_l, sd = sd_l)
    lj[lf] <- l1
    l0[lf] <- l1
    X <- X + lj %*% t(zj)
    Y <- Y + l0 %*% t(z0)
  }
  alldata[[k]] <- X
}


saveRDS(alldata, "fabia2clusters.rds")
datasets <- readRDS("fabia2clusters.rds")

library(Hmisc)
# run Pearson on datasets
# thresholds are arbitrary; 
graphs <- list()
for (j in 1:length(datasets)){
  result <- rcorr(t(datasets[[j]]))
  graphs[[j]] <- result$r
  graphs[[j]][result$P > 0.05] <- 0
  #graphs[[j]][which(graphs[[j]] > 0.2)] <- 1
  #graphs[[j]][which(graphs[[j]] < -0.6)] <- -1
  for (i in 1:n){
    for (k in 1:n){
      if (i == k){
        graphs[[j]][i,i] <- 0
      }
      # threshold can be used to get more networks with negative edges
      #if ((graphs[[j]][i,k] < 0.2) && (graphs[[j]][i,k] > -0.7)){
      #  graphs[[j]][i,k] <- 0
      
      #}
    }
  }
  # remove nodes with only 0s
  rem_nodes <- colSums(graphs[[j]] != 0)
  rem_nodes <- rem_nodes != 0
  graphs[[j]] <- graphs[[j]][rem_nodes, rem_nodes]
}

library(igraph)
# write all matrices to format that can be read by networkx
for (i in 1:50){
  graph <- graphs[[i]]
  graph <- graph_from_adjacency_matrix(graph, weighted=TRUE, mode=c("undirected"))
  name <- paste(getwd(), "/graph_", i, ".graphml", sep="")
  write_graph(graph, file=name, format="graphml")
}

library(WGCNA)
for (i in 1:50){
  # 0 is for unassigned nodes
  dynamicMods <- blockwiseModules(t(alldata[[i]]), networkType = "signed", TOMType="signed")
  dynamicMods <- dynamicMods$colors
  # generate dictionary of ints
  dynamicMods[dynamicMods == "grey"] <- 0
  for (b in 1:length(unique(dynamicMods))){
    color <- unique(dynamicMods)[[b]]
    if (color != 0){
      dynamicMods[dynamicMods == color] <- b
    }
  }
  write.csv(dynamicMods, paste(i, "_wgcna_signed.csv", sep=""))
}


for (i in 1:50){
  dynamicMods <- blockwiseModules(t(alldata[[i]]), networkType = "unsigned", TOMType="unsigned")
  dynamicMods <- dynamicMods$colors
  # generate dictionary of ints
  dynamicMods[dynamicMods == "grey"] <- 0
  for (b in 1:length(unique(dynamicMods))){
    color <- unique(dynamicMods)[[b]]
    if (color != 0){
      dynamicMods[dynamicMods == color] <- b
    }
  }
  write.csv(dynamicMods, paste(i, "_wgcna_unsigned.csv", sep=""))
}


################ 
### 3 clusters
################

setwd("fabia3")
# res <- makeFabiaDataBlocksPos(n=100, l=100, p=4, f1=25, f2=25, of1=25, of2=25, sd_noise=2, sd_z_noise=0.2, mean_z=3, sd_z=1, sd_l_noise=0.2, mean_l = 3, sd_l=0)
# data <- res$X
# heatmap(data, Rowv=NA)
replicates=50
# fabia source code
alldata = list()
n=100
l=90
p=3
f1=30
f2=30
of1=30
of2=30
sd_noise=2
sd_z_noise=0.2
mean_z=3
sd_z=1
sd_l_noise=3
mean_l=3
sd_l=1
for (k in 1:replicates){
  za <- rep(f1, p)   # za determines length
  la <- rep(f1, p)
  ZC <- list()
  LC <- list()
  X <- matrix(rnorm(l * n, mean = 0, sd = sd_noise), n, l)
  Y <- matrix(0, n, l)
  rownames(X) <- rownames(X, do.NULL = FALSE, prefix = "gene")
  colnames(X) <- colnames(X, do.NULL = FALSE, prefix = "sample")
  rownames(Y) <- rownames(X)
  colnames(Y) <- colnames(X)
  for (i in 1:p) {
    zj <- rnorm(l, mean = 0, sd = sd_z_noise)
    z0 <- as.vector(rep(0, l))
    # tf <- floor(runif(1) * (l - za[i]))
    # zf <- tf:(tf + za[i] - 1)
    # in the original Fabia code, the start of the biclustering is selected randomly
    # hence, the clusters overlap and a lot of noise appears
    # here, I set the bicluster boundaries so they make more sense
    startpos = 1 + (f1 * (i-1))
    endpos = f1 * i - 10  # 10 genes are completely random
    zf <- seq(startpos, endpos)
    ZC[[i]] <- zf
    z1 <- rnorm((length(zf)-10), mean = mean_z, sd = sd_z)
    zj[zf] <- z1
    z0[zf] <- z1
    lj <- rnorm(n, mean = 0, sd = sd_l_noise)
    l0 <- as.vector(rep(0, n))
    # uf <- floor(runif(1) * (n - la[i]))   # sample vars are also selected randomly
    # lf <- uf:(uf + la[i] - 1)
    lf <- seq(startpos, endpos)
    LC[[i]] <- lf
    l1 <- rnorm((length(lf)-10), mean = mean_l, sd = sd_l)
    lj[lf] <- l1
    l0[lf] <- l1
    X <- X + lj %*% t(zj)
    Y <- Y + l0 %*% t(z0)
  }
  alldata[[k]] <- X
}


saveRDS(alldata, "fabia3clusters.rds")
datasets <- readRDS("fabia3clusters.rds")

library(Hmisc)
graphs <- list()
for (j in 1:length(datasets)){
  result <- rcorr(t(datasets[[j]]))
  graphs[[j]] <- result$r
  graphs[[j]][result$P > 0.05] <- 0
  #graphs[[j]][which(graphs[[j]] > 0.2)] <- 1
  #graphs[[j]][which(graphs[[j]] < -0.6)] <- -1
  for (i in 1:n){
    for (k in 1:n){
      if (i == k){
        graphs[[j]][i,i] <- 0
      }
      #if ((graphs[[j]][i,k] < 0.2) && (graphs[[j]][i,k] > -0.7)){
      #  graphs[[j]][i,k] <- 0
      
      #}
    }
  }
  # remove nodes with only 0s
  rem_nodes <- colSums(graphs[[j]] != 0)
  rem_nodes <- rem_nodes != 0
  graphs[[j]] <- graphs[[j]][rem_nodes, rem_nodes]
}

library(igraph)
# write all matrices to format that can be read by networkx
for (i in 1:50){
  graph <- graphs[[i]]
  graph <- graph_from_adjacency_matrix(graph, weighted=TRUE, mode=c("undirected"))
  name <- paste(getwd(), "/graph_", i, ".graphml", sep="")
  write_graph(graph, file=name, format="graphml")
}

library(WGCNA)
for (i in 1:replicates){
  # 0 is for unassigned nodes
  dynamicMods <- blockwiseModules(t(alldata[[i]]), networkType = "signed", TOMType="signed")
  dynamicMods <- dynamicMods$colors
  # generate dictionary of ints
  dynamicMods[dynamicMods == "grey"] <- 0
  for (b in 1:length(unique(dynamicMods))){
    color <- unique(dynamicMods)[[b]]
    if (color != 0){
      dynamicMods[dynamicMods == color] <- b
    }
  }
  write.csv(dynamicMods, paste(i, "_wgcna_signed.csv", sep=""))
}


for (i in 1:replicates){
  dynamicMods <- blockwiseModules(t(alldata[[i]]), networkType = "unsigned", TOMType="unsigned")
  dynamicMods <- dynamicMods$colors
  # generate dictionary of ints
  dynamicMods[dynamicMods == "grey"] <- 0
  for (b in 1:length(unique(dynamicMods))){
    color <- unique(dynamicMods)[[b]]
    if (color != 0){
      dynamicMods[dynamicMods == color] <- b
    }
  }
  write.csv(dynamicMods, paste(i, "_wgcna_unsigned.csv", sep=""))
}