"""
This file contains the code for comparing optimized clustering algorithms.
Optimal parameters for the runs are selected through the file parameter_optimization.py.
"""


import networkx as nx
from manta.manta import cluster_graph
import numpy as np
import matplotlib.pyplot as plt
from community.community_louvain import best_partition
import markov_clustering as mc
from networkx.algorithms.community import girvan_newman, kernighan_lin_bisection
from networkx.algorithms.cuts import conductance, cut_size
import pandas as pd
from itertools import combinations
import seaborn as sns
from math import sqrt
from copy import deepcopy
import json
from scipy.stats import wilcoxon


def cluster_comparison(posenv, alg_clusters):
    """
    Given two lists of clusters, this function
    identifies which clusters are the most similar to each other
    and returns the number of nodes that are assigned to the same or opposite
    cluster.
    Update: clusters with a size larger than 80% of the number of species are ignored.
    These tend to get high sensitivity and high separation.
    :param posenv: Clusters generated from environmental data
    :param alg_clusters: Clusters generated from algorithm
    :return: Score tuple
    """
    # as described by Brohee et al 2006
    # for each cluster:
    # calculate the complex-wise sensitivity
    # calculate cluster-wise positive predictive value
    # compute weighted mean of both for all clusters
    # use these to calculate geometrical accuracy
    # geometrical mean of averaged Sn and PPV values
    # for better estimations of PPV,
    # it is important that nodes present in alg_clusters
    # but not in posenv are removed
    select_clusters = deepcopy(alg_clusters)
    large_cluster = False
    species = sum([len(item) for item in alg_clusters])
    sn = np.nan
    ppv = np.nan
    acc = np.nan
    sep = np.nan
    for item in alg_clusters:
        if len(item) > (0.8 * species):
            large_cluster = True
    # if there are more than 50 small clusters,
    # the outcome is also filtered
    if len(alg_clusters) > 50:
        large_cluster = True
    if not large_cluster:
        posnodes = [item for sublist in posenv for item in sublist]
        for x in range(len(alg_clusters)):
            for node in alg_clusters[x]:
                if node not in posnodes:
                    select_clusters[x].remove(node)
        matches = np.zeros(shape=(len(posenv), len(select_clusters)))
        for i in range(len(posenv)):
            for j in range(len(select_clusters)):
                matches[i, j] = len(set(select_clusters[j]).intersection(posenv[i]))
        # calculate sensitivity
        sensitivity = matches.copy()
        for i in range(len(posenv)):
            for j in range(len(select_clusters)):
                sensitivity[i, j] /= len(posenv[i])
        # calculate maximal fraction of env cluster assigned to same cluster
        max_sensitivity = np.amax(sensitivity, axis=1)
        total = 0
        for i in range(len(posenv)):
            max_sensitivity[i] *= len(posenv[i])
            total += len(posenv[i])
        sn = np.sum(max_sensitivity) / total
        # calculate positive predictive value
        precision = matches.copy()
        for j in range(len(select_clusters)):
            if np.sum(precision[:, j]) != 0:
                precision[:, j] /= np.sum(precision[:, j])
            else:
                precision[:, j] = 0
        # calculate maximal fraction of cluster assigned to env cluster
        max_precision = np.amax(precision, axis=0)
        total = 0
        for i in range(len(select_clusters)):
            max_precision[i] *= len(select_clusters[i])
            total += len(select_clusters[i])
        ppv = np.sum(max_precision) / total
        acc = sqrt(sn * ppv)  # geometrical accuracy
        # separation; intersections between clusters
        # first part is equal to ppv
        colfreq = matches.copy()
        for j in range(len(select_clusters)):
            if np.sum(precision[:, j]) != 0:
                colfreq[:, j] /= np.sum(colfreq[:, j])
            else:
                colfreq[:, j] = 0
        rowfreq = matches.copy()
        for j in range(len(posenv)):
            if np.sum(rowfreq[j:, ]) != 0:
                rowfreq[j:, ] /= np.sum(rowfreq[j, :])
            else:
                rowfreq[j:, ] = 0
        separation = rowfreq * colfreq
        sepco = np.mean(np.sum(separation, axis=1))  # complex-wise separation
        sepcl = np.mean(np.sum(separation, axis=0))  # cluster-wise separation
        sep = sqrt(sepco * sepcl)  # geometrical accuracy
    return sn, ppv, acc, sep


def cluster_sparsity(graph, alg_clusters):
    """
    Defines clustering sparsity as used internally in manta for
    lists of cluster identities.
    :param graph: NetworkX graph
    :param alg_clusters: Clusters generated from algorithm
    :return: Sparsity score
    """
    cut_score = 1/len(graph.edges)
    sparsity = 0
    edges = list()
    for cluster_id in range(len(alg_clusters)):
        # get the set of edges that is NOT in either cluster
        node_ids = alg_clusters[cluster_id]
        cluster = graph.subgraph(node_ids)
        edges.extend(list(cluster.edges))
        # penalize for having negative edges inside cluster
        weights = nx.get_edge_attributes(cluster, 'weight')
        for x in weights:
            if weights[x] < 0:
                sparsity -= cut_score
            else:
                sparsity += cut_score
    all_edges = list(graph.edges)
    cuts = list()
    for edge in all_edges:
        if edge not in edges and (edge[1], edge[0]) not in edges:
            # problem with cluster edges having swapped orders
            cuts.append(edge)
    for edge in cuts:
        cut = graph[edge[0]][edge[1]]['weight']
        if cut > 0:
            sparsity -= cut_score
        else:
            sparsity += cut_score
    return sparsity


def cluster_quality(graph, alg_clusters):
    """
    Conductance
    for the cluster assignments.
    :param graph: NetworkX graph
    :param alg_clusters: Clusters generated from algorithm
    :return: Score tuple
    """
    # conductance is only defined for 2 sets
    # more clusters than 2 can be defined
    # therefore, we calculate the mean conductance
    conductances = list()
    for cluster in range(len(alg_clusters)):
        if (len(alg_clusters[cluster]) != 100) and (len(alg_clusters[cluster]) != 1):
            # first check if there are even edges between clusters
            t = set(graph) - set(alg_clusters[cluster])
            num_cut_edges = cut_size(graph, alg_clusters[cluster], t, weight=None)
            if num_cut_edges != 0:
                conductances.append(conductance(graph, alg_clusters[cluster]))
            else:
                conductances.append(0)
        else:
            conductances.append(0)
    results = np.mean(conductances)
    return results


def run_algorithms(network, wgcna, clusnum, edges):
    """
    Returns a list of clustering assignments per clustering algorithm.
    :param network: Graph to be clustered.
    :param wgcna: WGCNA graphs (tuple combining signed and unsigned)
    :param clusnum: Number of clusters in the original graph.
    :param edges: Positive or negative edge network
    :return: One list of clustering assigments per algorithm.
    """
    if edges == "negative":
        clusters = cluster_graph(network, limit=2, ratio=0.8, permutations=100, verbose=False,
                                 max_clusters=6, min_clusters=2, min_cluster_size=0.2,
                                 iterations=20, subset=0.8,
                                 edgescale=0.3)[0]
        output = nx.get_node_attributes(clusters, name='cluster')
        fuzzy = nx.get_node_attributes(clusters, name='assignment')
        manta = list()
        # convert dictionary of cluster assignments to
        # cluster lists of nodes
        for k in range(len(set(output.values()))):
            manta.append(list())
            for node in output:
                if len(fuzzy) > 0:
                    if output[node] == list(set(output.values()))[k] and fuzzy[node] != 'weak':
                        manta[k].append(node)
                else:
                    # memory effect not always present,
                    # fuzziness cannot be determined without memory effect
                    if output[node] == list(set(output.values()))[k]:
                        manta[k].append(node)
        manta_fuzzy = list()
        # convert dictionary of cluster assignments to
        # cluster lists of nodes
        for k in range(len(set(output.values()))):
            manta_fuzzy.append(list())
            for node in output:
                if output[node] == list(set(output.values()))[k]:
                    manta_fuzzy[k].append(node)
        # WGCNA signed
        # we are using 6 as a soft power threshold
        # may be better to optimize
        signed_file = wgcna[0]
        unsigned_file = wgcna[1]
        wgcna_plus = list()
        for k in range(len(set(signed_file))):
            wgcna_plus.append(list())
            for node in range(len(signed_file)):
                if signed_file[node] == list(set(signed_file))[k] and signed_file[node] != 0:
                    wgcna_plus[k].append("n" + str(node))

        wgcna_min = list()
        for k in range(len(set(unsigned_file))):
            wgcna_min.append(list())
            for node in range(len(unsigned_file)):
                if unsigned_file[node] == list(set(unsigned_file))[k] and unsigned_file[node] != 0:
                    wgcna_min[k].append("n" + str(node))
    else:
        manta = None
        manta_fuzzy = None
        wgcna_plus = None
        wgcna_min = None
    # Louvain community detection
    unweighted_graph = network.copy()
    for u, v, d in unweighted_graph.edges(data=True):
        d['weight'] = 1
    if edges == 'negative':
        clusters = best_partition(unweighted_graph, resolution=0.1)
    else:
        clusters = best_partition(unweighted_graph, resolution=1)
    louvain = list()
    for k in range(len(set(clusters.values()))):
        louvain.append(list())
        for node in clusters:
            if clusters[node] == list(set(clusters.values()))[k]:
                louvain[k].append(node)
    # MCL
    mcl = list()
    matrix = nx.to_scipy_sparse_matrix(network)
    matrix[matrix == -1] = 1
    # changed expansion to 10
    if edges == 'negative':
        result = mc.run_mcl(matrix, expansion=15, inflation=3)
    else:
        result = mc.run_mcl(matrix, expansion=7, inflation=2)
    clusters = mc.get_clusters(result)
    for k in range(len(clusters)):
        mcl.append(list(clusters[k]))
    nodedict = dict.fromkeys(network.nodes)
    i = 0
    for key in list(network.nodes):
        nodedict[key] = i
        i += 1
    nodedict = {v: k for k, v in nodedict.items()}
    for cluster in range(len(mcl)):
        for node in range(len(mcl[cluster])):
            mcl[cluster][node] = nodedict[mcl[cluster][node]]
    # Girvan-Newman clustering
    # NOTE: Girvan-Newman returns a dendrogram,
    # for third cluster select next branch!
    girvan = list()
    # repeat twice for 3 cluster assignment
    results = girvan_newman(network)
    for k in range(clusnum - 1):
        clusters = tuple(sorted(c) for c in next(results))
    for k in range(len(clusters)):
        girvan.append(clusters[k])
    if clusnum == 2:
        # Kernighan-Lin algorithm
        kernighan = list()
        clusters = kernighan_lin_bisection(network)
        for k in range(len(clusters)):
            kernighan.append(list(clusters[k]))
    else:
        kernighan = None
    return manta, manta_fuzzy, wgcna_plus, wgcna_min, louvain, mcl, girvan, kernighan


def evaluation_results(sourcename, sourceloc, outloc, clusnum, replicates, mode, wgcna, perm=False,
                       figure=True):
    """
    Given a filepath leading to the the graph files,
    as well as the number of clusters and the filename of the saved figure,
    this function carries out clustering on all supplied files.
    :param sourcename: Filepath to graph files
    :param sourceloc: Filepath leading to other (WGCNA and growthrate) files
    :param clusnum: Number of clusters
    :param outloc: Output location for cluster json file
    :param replicates: Number of graph replicates
    :param mode: fabia or klemm simulation
    :param wgcna: wgcna filename prefix
    :param perm: if true, processes wgcna filenames differently
    :param figure: If true, generate figure
    :return:
    """
    networks = list()
    positive_networks = list()
    manta_clusters = list()
    manta_clusters_fuzzy = list()
    wgcna_signed = list()
    wgcna_unsigned = list()
    louvain_clusters = list()
    louvain_clusters_positive = list()
    mcl_clusters = list()
    mcl_clusters_positive = list()
    girvan_clusters = list()
    girvan_clusters_positive = list()
    kernighan_clusters = list()
    kernighan_clusters_positive = list()
    # for each alg, we generate a list of clusters

    for i in range(replicates):
        filename = sourcename + str(i + 1) + ".graphml"
        network = nx.read_graphml(filename)
        # shift edges to positive range
        # weights = nx.get_edge_attributes(network, 'weight')
        # minval = np.min(list(weights.values()))
        # for key in weights:
        #    weights[key] -= minval
        # nx.set_edge_attributes(network, weights, 'weight')
        #
        networks.append(network)
        posnet = nx.Graph(((source, target, attr) for source, target, attr in
                           network.edges(data=True) if attr['weight'] > 0))
        positive_networks.append(posnet)
        if perm:
            signed_name = sourceloc + wgcna[0][0] + "_" + str(i+1) + wgcna[0][1]
            unsigned_name = sourceloc + wgcna[1][0] + "_" + str(i+1) + wgcna[1][1]
        else:
            signed_name = sourceloc + str(i + 1) + wgcna[0]
            unsigned_name = sourceloc + str(i + 1) + wgcna[1]
        signed_file = pd.read_csv(signed_name)['x'].tolist()
        unsigned_file = pd.read_csv(unsigned_name)['x'].tolist()
        manta, manta_fuzzy, wgcna_plus, wgcna_min, louvain, mcl, girvan, kernighan = \
            run_algorithms(network=network, wgcna=(signed_file, unsigned_file), clusnum=clusnum, edges="negative")
        manta_clusters.append(manta)
        manta_clusters_fuzzy.append(manta_fuzzy)
        wgcna_signed.append(wgcna_plus)
        wgcna_unsigned.append(wgcna_min)
        louvain_clusters.append(louvain)
        mcl_clusters.append(mcl)
        girvan_clusters.append(girvan)
        kernighan_clusters.append(kernighan)

        manta, mantafuzzy, wgcnaplus, wgcnamin, louvain, mcl, girvan, kernighan = \
            run_algorithms(network=posnet, wgcna=None, clusnum=clusnum, edges="positive")
        louvain_clusters_positive.append(louvain)
        mcl_clusters_positive.append(mcl)
        girvan_clusters_positive.append(girvan)
        kernighan_clusters_positive.append(kernighan)

        # we will also run on permuted networks
    if clusnum == 2:
        clusters = {'manta': manta_clusters,
                    'manta, no fuzzy cluster': manta_clusters_fuzzy,
                    'WGCNA signed': wgcna_signed,
                    'WGCNA unsigned': wgcna_unsigned,
                    'Louvain': louvain_clusters,
                    'Louvain +': louvain_clusters_positive,
                    'MCL': mcl_clusters,
                    'MCL +': mcl_clusters_positive,
                    'Girvan-Newman': girvan_clusters,
                    'Girvan-Newman +': girvan_clusters_positive,
                    'Kernighan-Lin': kernighan_clusters,
                    'Kernighan-Lin +': kernighan_clusters_positive}
    else:
        clusters = {'manta': manta_clusters,
                    'manta, no fuzzy cluster': manta_clusters_fuzzy,
                    'WGCNA signed': wgcna_signed,
                    'WGCNA unsigned': wgcna_unsigned,
                    'Louvain': louvain_clusters,
                    'Louvain +': louvain_clusters_positive,
                    'MCL': mcl_clusters,
                    'MCL +': mcl_clusters_positive,
                    'Girvan-Newman': girvan_clusters,
                    'Girvan-Newman +': girvan_clusters_positive}

    # we can get the effect of growth rates to determine 'likely' cluster assignments
    if mode == 'fabia':
        env_clusters = list()
        for j in range(replicates):
            env_clusters.append(list())
            for i in range(2):
                env_clusters[j].append(list())
            env_clusters[j][0] = list('n' + str(x) for x in list(range(1, 31)))
            env_clusters[j][1] = list('n' + str(x) for x in list(range(41, 91)))
    elif mode == 'klemm':
        env_clusters = list()
        for j in range(replicates):
            env_clusters.append(list())
            env = pd.read_csv((sourceloc + "growthrates_" + str(j + 1) + ".csv"))
            # we can find out if a taxon is positively associated to
            # a cluster, if the differences are large
            env = env.drop(['Unnamed: 0'], axis=1)
            means = env.mean(axis=1)
            maxids = env.idxmax(axis=1)
            maxes = env.max(axis=1)
            # get index of largest value
            # if maximum value is larger than the mean above a threshold,
            # the node is considered to belong to that specific cluster
            # update this code because sensitivity
            # and precision make no sense now
            for i in range(clusnum):
                env_clusters[j].append(list())
            # threshold arbitrary
            threshold = 0.3
            for i in range(len(maxids)):
                if maxids[i] == 'V1' and abs(maxes[i] / means[i]) > threshold:
                    env_clusters[j][0].append('n' + str(i))
                elif maxids[i] == 'V2' and abs(maxes[i] / means[i]) > threshold:
                    env_clusters[j][1].append('n' + str(i))
                elif maxids[i] == 'V3' and abs(maxes[i] / means[i]) > threshold:
                    env_clusters[j][2].append('n' + str(i))
            # this way, we only find nodes positively associated to clusters
            # strong negative associations to 1 cluster are not picked up

    if clusnum == 2:
        envresults = pd.DataFrame(np.zeros(shape=(12 * replicates, 6)))
    else:
        envresults = pd.DataFrame(np.zeros(shape=(10 * replicates, 6)))
    envresults.columns = ['Algorithm', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity']
    envresults['Algorithm'] = envresults['Algorithm'].astype(str)
    k = 0
    for i in range(replicates):
        for cluster in clusters:
            envresults.iloc[k, 0] = cluster
            results = cluster_comparison(env_clusters[i], clusters[cluster][i])
            envresults.iloc[k, 1] = results[0]
            envresults.iloc[k, 2] = results[1]
            envresults.iloc[k, 3] = results[1]
            envresults.iloc[k, 4] = results[3]
            envresults.iloc[k, 5] = cluster_sparsity(networks[i], clusters[cluster][i])
            k += 1

    # nested barplot
    env_melted = pd.melt(envresults, id_vars="Algorithm")
    env_melted['Class'] = env_melted['Algorithm'].astype(str).str[:3]
    env_melted['Class'] = env_melted['Class'].str.replace("man", "manta")
    env_melted['Class'] = env_melted['Class'].str.replace("Lou", "Louvain")
    env_melted['Class'] = env_melted['Class'].str.replace("Ker", "Kernighan-Lin")
    env_melted['Class'] = env_melted['Class'].str.replace("Gir", "Girvan-Newman")
    env_melted['Class'] = env_melted['Class'].str.replace("WGC", "WGCNA")
    if not perm:
        env_melted.to_csv(outloc + "_data.csv")
    if figure:
        sns.set(style="whitegrid", palette="cubehelix", font_scale=2)
        figure1 = sns.catplot(x="value", y="Algorithm", col="variable", hue="Class", dodge=False,
                              data=env_melted, kind="violin", inner=None, col_wrap=3, palette="muted", legend=False)
        figure1.set_ylabels("")
        figure1.set_xlabels("")
        for i in range(len(figure1.axes)):
            ax = figure1.axes[i]
            ax.set_title(envresults.columns[i + 1])
            ax.set_xlim(0, 1)
            ax.set_xticks([-1, -0.5, 0, 0.5, 1])
            ax.margins(y=0.1)
        snset = env_melted[env_melted['variable'] == 'Sn']
        algs = ['manta', 'manta, no fuzzy cluster', 'WGCNA signed', 'WGCNA unsigned',
                'Louvain', 'Louvain +', 'MCL', 'MCL +', 'Girvan-Newman', 'Girvan-Newman +',
                'Kernighan-Lin', 'Kernighan-Lin +']
        ax = figure1.axes[0]
        textrange = range(5, 125, 10)
        for j in range(len(algs)):
            algset = snset[snset['Algorithm'] == algs[j]]
            # count non na sn occurrences
            num_sn = len(np.isnan(algset['value'][np.isnan(algset['value']) != True]))
            y = textrange[j]/10
            ax.text(s=str(num_sn), x=1.1, y=y, size=20)
        plt.subplots_adjust(left=0.23)
        plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
        plt.subplots_adjust(hspace=0.3, wspace=0.3)
        plt.savefig(outloc + "_results.pdf", format="pdf", dpi=1200, papertype='a5')
    return env_melted


def evaluation_perms(sourcename, sourceloc, outloc, clusnum, replicates, mode):
    allresults = list()
    permrange = 10
    figure = False
    if sourcename[-5:] == 'perm_':
        wgcnanames = ("_wgcna_signed_perm.csv", "_wgcna_unsigned_perm.csv")
    elif sourcename[-5:] == 'mial_':
        wgcnanames = ("_wgcna_signed_multinomial.csv", "_wgcna_unsigned_multinomial.csv")
        permrange = 2
        figure = True
    for i in range(1, permrange):
        permname = sourcename + str(i) + "_"
        results = evaluation_results(permname, sourceloc, outloc,
                                     figure=figure, clusnum=clusnum, replicates=replicates, mode=mode,
                                     wgcna=([str(i), wgcnanames[0]],
                                            [str(i), wgcnanames[1]]), perm=True)
        results['Permutation'] = i * 0.1
        allresults.append(results)
        print('Working on iteration ' + str(i))
    results = pd.concat(allresults)
    if not figure:
        results.to_csv(outloc + "data.csv")
    results['Size'] = results['Algorithm']
    # dictionary for assigning line types
    linedict = {'Girvan-Newman': 'Positive edges, signed and \nnon-fuzzy networks',
                'Louvain': 'Positive edges, signed and \nnon-fuzzy networks',
                'MCL': 'Positive edges, signed and \nnon-fuzzy networks',
                'WGCNA signed': 'Positive edges, signed and \nnon-fuzzy networks',
                'manta': 'Positive edges, signed and \nnon-fuzzy networks',
                'Girvan-Newman +': 'Negative edges, unsigned and \nfuzzy networks',
                'Louvain +': 'Negative edges, unsigned and \nfuzzy networks',
                'MCL +': 'Negative edges, unsigned and \nfuzzy networks',
                'WGCNA unsigned': 'Negative edges, unsigned and \nfuzzy networks',
                'manta, no fuzzy cluster': 'Negative edges, unsigned and \nfuzzy networks',
                'Kernighan-Lin': 'Negative edges, unsigned and \nfuzzy networks',
                'Kernighan-Lin +': 'Positive edges, signed and \nnon-fuzzy networks'}

    results = results.replace({'Size': linedict})
    # retain only 'good' results for ease of interpretation of the figures
    results = results[results['Algorithm'] != 'manta']
    results = results[results['Algorithm'] != 'Girvan-Newman']
    results = results[results['Algorithm'] != 'Kernighan-Lin +']
    results = results[results['Algorithm'] != 'Louvain']
    results = results[results['Algorithm'] != 'MCL +']
    results = results[results['Algorithm'] != 'WGCNA unsigned']
    # sparsity = results.loc[results['variable'].isin(['Sparsity'])]
    # sns.set(style="whitegrid", palette="cubehelix", font_scale=1)
    # figure1 = sns.relplot(x="Permutation", y="value", col_wrap=3,
    #                      hue="Class", col="variable", palette="muted",
    #                      kind="line", legend="full", size='Size', data=results)

    # figure1 = sns.relplot(x="Permutation", y="value", hue="Class", err_style='bars',
    #                       palette="muted", size="Size", col="variable",
    #                       data=sparsity, kind="line", legend='full')
    # figure1.set_ylabels("Sparsity")
    # figure1.set_xlabels("Permuted fraction")
    # figure1.axes[0][0].set_title("")
    # plt.subplots_adjust(right=0.6, left=0.1)
    # plt.savefig(outloc + "_permsparsity.png")
    # also do figure with all vars except sparsity
    if not figure:
        sns.set(style="whitegrid", palette="cubehelix", font_scale=2)
        # omit = results[results['variable'] != 'Sparsity']
        # old style plot
        # figure1 = sns.relplot(x="Permutation", y="value", col="variable",
        #                       hue="Algorithm",
        #                       data=omit, kind="scatter", col_wrap=2, palette="muted", legend='full')
        omit = results[results['variable'] == 'Sep']
        figure1 = sns.relplot(x="Permutation", y="value", col="Algorithm",
                              data=omit, kind="scatter", col_wrap=2, palette="muted", legend='full')
        figure1.set_ylabels("Separation")
        figure1.set_xlabels("Permuted fraction")
        names = ['manta', 'WGCNA signed', 'Louvain +', 'MCL', 'Girvan-Newman +', 'Kernighan-Lin']
        for i in range(len(figure1.axes)):
            ax = figure1.axes[i]
            ax.set_title(names[i])
            ax.set_xlim(0, 1)
            ax.set_ylim(0, 1)
            ax.set_xticks([0, 0.3, 0.6, 0.9])
        plt.subplots_adjust(left=0.23)
        # plt.savefig(outloc + "_results.png")
        plt.savefig(outloc + "_results.pdf", format="pdf", papertype='a4', dpi=1200)
    return results


def significant_differences(results, significant=True, manta=True):
    # only compare manta to other algs;
    # otherwise too many sig pvals
    if not manta:
        pvals = pd.DataFrame(np.zeros(shape=(len(list(combinations(set(results['Algorithm']),
                                                                   2)))*len(set(results['variable'])), 3)))
    else:
        pvals = pd.DataFrame(np.zeros(shape=(len(set(results['Algorithm'])) * len(set(results['variable'])), 3)))

    pvals.columns = ['Algorithm', 'variable', 'value']
    if not manta:
        pvals['Algorithm'] = list(combinations(set(results['Algorithm']), 2))*len(set(results['variable']))
        pvals['variable'] = list(set(results['variable'])) * len(list(combinations(set(results['Algorithm']), 2)))
    else:
        pvals['Algorithm'] = list(set(results['Algorithm']))*len(set(results['variable']))
        pvals['variable'] = list(set(results['variable'])) * len(list(set(results['Algorithm'])))
    if not manta:
        for combo in set(combinations(results['Algorithm'], 2)):
            for variable in set(results['variable']):
                subresults = results[results['variable'] == variable]
                # replace Na values with 0
                subresults = subresults.fillna(0)
                rowids = pvals[pvals['variable'] == variable]
                pval = wilcoxon(subresults[subresults['Algorithm'] == combo[0]]['value'],
                                subresults[subresults['Algorithm'] == combo[1]]['value'])
                rowid = rowids[rowids['Algorithm'] == combo].index
                pvals.loc[rowid, 'value'] = pval[1]
    else:
        for combo in set(results['Algorithm']):
            if combo != 'manta, no fuzzy cluster':
                for variable in set(results['variable']):
                    subresults = results[results['variable'] == variable]
                    # replace Na values with 0
                    subresults = subresults.fillna(0)
                    rowids = pvals[pvals['variable'] == variable]
                    pval = wilcoxon(subresults[subresults['Algorithm'] == 'manta, no fuzzy cluster']['value'],
                                    subresults[subresults['Algorithm'] == combo]['value'])
                    rowid = rowids[rowids['Algorithm'] == combo].index
                    pvals.loc[rowid, 'value'] = pval[1]
    # only return significant values
    if significant:
        pvals = pvals[pvals['value'] < 0.05]
    return pvals


# replace this with correct file location
archive = ".."

# get node connectivity for fabia and lotka-volterra networks
fabia = list()
lotka = list()
for i in range(50):
    filename = archive + "fabia2//graph_" + str(i + 1) + ".graphml"
    network = nx.read_graphml(filename)
    fabia.append(nx.node_connectivity(network))
    filename = archive + "random2//graph_" + str(i + 1) + ".graphml"
    network = nx.read_graphml(filename)
    lotka.append(nx.node_connectivity(network))
np.median(fabia)
np.median(lotka)

fabia2graph = archive + "fabia2//graph_"
fabia2loc = archive + "fabia2//"
fabia2out = archive + "Figures//fabia2"
fabia2results = evaluation_results(sourcename=fabia2graph, sourceloc=fabia2loc, outloc=fabia2out,
                                   clusnum=2, replicates=50, mode="fabia",
                                   wgcna=("_wgcna_signed.csv", "_wgcna_unsigned.csv"))
print("Completed fabia 2")

fabia3graph = archive + "fabia3//graph_"
fabia3loc = archive + "fabia3//"
fabia3out = archive + "Figures//fabia3"
fabia3results = evaluation_results(sourcename=fabia3graph, sourceloc=fabia3loc, outloc=fabia3out,
                                   clusnum=3, replicates=50, mode="fabia",
                                   wgcna=("_wgcna_signed.csv", "_wgcna_unsigned.csv"))
print("Completed fabia 3")

# permutations

fabia2graph = archive + "fabia2//graph_perm_"
fabia2loc = archive + "fabia2//"
fabia2out = archive + "Figures//fabia2_perm"
fabia2perms = evaluation_perms(sourcename=fabia2graph, sourceloc=fabia2loc, outloc=fabia2out,
                               clusnum=2, replicates=50, mode="fabia")
print("Completed fabia 2 permutation")

fabia3graph = archive + "fabia3//graph_perm_"
fabia3loc = archive + "fabia3//"
fabia3out = archive + "Figures//fabia3_perm"
fabia3perms = evaluation_perms(sourcename=fabia3graph, sourceloc=fabia3loc,  outloc=fabia3out,
                               clusnum=3, replicates=50, mode="fabia")
print("Completed fabia 3 permutation")

random2graph = archive + "random2//graph_"
random2loc = archive + "random2//"
random2out = archive + "Figures//random2"
random2results = evaluation_results(sourcename=random2graph, sourceloc=random2loc, outloc=random2out,
                                  wgcna=("_wgcna_signed.csv", "_wgcna_unsigned.csv"), clusnum=2, replicates=50, mode="klemm")
print("Completed random 2")

random3graph = archive + "random3//graph_"
random3loc = archive + "random3//"
random3out = archive + "Figures//random3"
random3results = evaluation_results(sourcename=random3graph, sourceloc=random3loc, outloc=random3out,
                                  wgcna=("_wgcna_signed.csv", "_wgcna_unsigned.csv"), clusnum=3, replicates=50, mode="klemm")
print("Completed random 3")

random2graph = archive + "random2//graph_perm_"
random2loc = archive + "random2//"
random2out = archive + "Figures//random2_perm"
random2perms = evaluation_perms(sourcename=random2graph, sourceloc=random2loc, outloc=random2out,
                                clusnum=2, replicates=50, mode="klemm")
print("Completed random 2 permutation")

random3graph = archive + "random3//graph_perm_"
random3loc = archive + "random3//"
random3out = archive + "Figures//random3_perm"
random3perms = evaluation_perms(sourcename=random3graph, sourceloc=random3loc, outloc=random3out,
                                clusnum=3, replicates=50, mode="klemm")
print("Completed random 3 permutation")

random2graph = archive + "random2//graph_multinomial_"
random2loc = archive + "random2//"
random2out = archive + "Figures//random2_multinomial"
random2perms = evaluation_perms(sourcename=random2graph, sourceloc=random2loc, outloc=random2out,
                                clusnum=2, replicates=50, mode="klemm")
print("Completed random 2 multinomial")

random2graph = archive + "random2//graph_normalized_"
random2loc = archive + "random2//"
random2out = archive + "Figures//random2_normalized"
random2results = evaluation_results(sourcename=random2graph, sourceloc=random2loc, outloc=random2out,
                                  wgcna=("_wgcna_signed.csv", "_wgcna_unsigned.csv"), clusnum=2, replicates=50, mode="klemm")
print("Completed random 2 normalized")
