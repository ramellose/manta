"""
Parameters for the tested algorithms are compared in this file.
"""

import networkx as nx
from manta.cluster import cluster_graph
import numpy as np
import sys
import matplotlib.pyplot as plt
from community.community_louvain import best_partition
import markov_clustering as mc
from networkx.algorithms.community import girvan_newman, kernighan_lin_bisection
from networkx.algorithms.cuts import conductance, cut_size
import pandas as pd
import seaborn as sns
from math import sqrt
from copy import deepcopy

archive = ".."
env_clusters = list()
for i in range(50):
    env = pd.read_csv((archive + "klemm2//growthrates_" + str(i+1) + ".csv"))
    diff = env['V1'] - env['V2']
    env_clusters.append(list())
    # 0.2 threshold arbitrary
    cluster1 = ['n' + str(x) for x in list(diff[diff > 0.3].index)]
    env_clusters[i].append(cluster1)
    cluster1 = ['n' + str(x) for x in list(diff[diff < -0.3].index)]
    env_clusters[i].append(cluster1)

networks = list()
positive_networks = list()
for i in range(50):
    filename = archive + "klemm2//graph_" + str(i+1) + ".graphml"
    network = nx.read_graphml(filename)
    networks.append(network)
    posnet = nx.Graph(((source, target, attr) for source, target, attr in
                       network.edges(data=True) if attr['weight'] > 0))
    positive_networks.append(posnet)


def cluster_comparison(posenv, alg_clusters):
    """
    Given two lists of clusters, this function
    identifies which clusters are the most similar to each other
    and returns the number of nodes that are assigned to the same or opposite
    cluster.
    Update: clusters with a size larger than 80% of the number of species are ignored.
    These tend to get high sensitivity and high separation.
    :param posenv: Clusters generated from environmental data
    :param alg_clusters: Clusters generated from algorithm
    :param manta: If clusters are generated with manta, the first cluster (fuzzy nodes) is ignored
    :return: Score tuple
    """
    # as described by Brohee et al 2006
    # for each cluster:
    # calculate the complex-wise sensitivity
    # calculate cluster-wise positive predictive value
    # compute weighted mean of both for all clusters
    # use these to calculate geometrical accuracy
    # geometrical mean of averaged Sn and PPV values
    # for better estimations of PPV,
    # it is important that nodes present in alg_clusters
    # but not in posenv are removed
    select_clusters = deepcopy(alg_clusters)
    large_cluster = False
    species = sum([len(item) for item in alg_clusters])
    for item in alg_clusters:
        if len(item) > (0.8 * species):
            sn = np.nan
            ppv = np.nan
            acc = np.nan
            sep = np.nan
            large_cluster = True
    if not large_cluster:
        posnodes = [item for sublist in posenv for item in sublist]
        for x in range(len(alg_clusters)):
            for node in alg_clusters[x]:
                if node not in posnodes:
                    select_clusters[x].remove(node)
        matches = np.zeros(shape=(len(posenv), len(select_clusters)))
        for i in range(len(posenv)):
            for j in range(len(select_clusters)):
                matches[i,j] = len(set(select_clusters[j]).intersection(posenv[i]))
        # calculate sensitivity
        sensitivity = matches.copy()
        for i in range(len(posenv)):
            for j in range(len(select_clusters)):
                sensitivity[i, j] /= len(posenv[i])
        # calculate maximal fraction of env cluster assigned to same cluster
        max_sensitivity = np.amax(sensitivity, axis=1)
        total = 0
        for i in range(len(posenv)):
            max_sensitivity[i] *= len(posenv[i])
            total += len(posenv[i])
        sn = np.sum(max_sensitivity) / total
        # calculate positive predictive value
        precision = matches.copy()
        for j in range(len(select_clusters)):
            if np.sum(precision[:,j]) != 0:
                precision[:,j] /= np.sum(precision[:,j])
            else:
                precision[:, j] = 0
        # calculate maximal fraction of cluster assigned to env cluster
        max_precision = np.amax(precision, axis=0)
        total = 0
        for i in range(len(select_clusters)):
            max_precision[i] *= len(select_clusters[i])
            total += len(select_clusters[i])
        ppv = np.sum(max_precision) / total
        acc = sqrt(sn * ppv)  # geometrical accuracy
        # separation; intersections between clusters
        # first part is equal to ppv
        # NOT CORRECT YET should be between 0 and 1
        colfreq = matches.copy()
        for j in range(len(select_clusters)):
            if np.sum(precision[:, j]) != 0:
                colfreq[:, j] /= np.sum(colfreq[:, j])
            else:
                colfreq[:, j] = 0
        rowfreq = matches.copy()
        for j in range(len(posenv)):
            if np.sum(rowfreq[j:, ]) != 0:
                rowfreq[j:, ] /= np.sum(rowfreq[j, :])
            else:
                rowfreq[j:, ] = 0
        separation = rowfreq * colfreq
        sepco = np.mean(np.sum(separation, axis=1))  # complex-wise separation
        sepcl = np.mean(np.sum(separation, axis=0))  # cluster-wise separation
        sep = sqrt(sepco * sepcl)  # geometrical accuracy
    return (sn, ppv, acc, sep)


def cluster_sparsity(graph, alg_clusters):
    """
    Defines clustering sparsity as used internally in manta for
    lists of cluster identities.
    :param graph: NetworkX graph
    :param alg_clusters: Clusters generated from algorithm
    :return: Sparsity score
    """
    cut_score = 1/len(graph.edges)
    sparsity = 0
    edges = list()
    for cluster_id in range(len(alg_clusters)):
        # get the set of edges that is NOT in either cluster
        node_ids = alg_clusters[cluster_id]
        cluster = graph.subgraph(node_ids)
        edges.extend(list(cluster.edges))
        # penalize for having negative edges inside cluster
        weights = nx.get_edge_attributes(cluster, 'weight')
        for x in weights:
            if weights[x] < 0:
                sparsity -= cut_score
            else:
                sparsity += cut_score
    all_edges = list(graph.edges)
    cuts = list()
    for edge in all_edges:
        if edge not in edges and (edge[1], edge[0]) not in edges:
            # problem with cluster edges having swapped orders
            cuts.append(edge)
    for edge in cuts:
        cut = graph[edge[0]][edge[1]]['weight']
        if cut > 0:
            sparsity -= cut_score
        else:
            sparsity += cut_score
    return sparsity


def cluster_quality(graph, alg_clusters):
    """
    Conductance
    for the cluster assignments.
    :param graph: NetworkX graph
    :param alg_clusters: Clusters generated from algorithm
    :param manta: If clusters are generated with manta, the first cluster (fuzzy nodes) is ignored
    :return: Score tuple
    """
    # conductance is only defined for 2 sets
    # more clusters than 2 can be defined
    # therefore, we calculate the mean conductance
    conductances = list()
    for cluster in range(len(alg_clusters)):
        if (len(alg_clusters[cluster]) != 100) and (len(alg_clusters[cluster]) != 1):
            # first check if there are even edges between clusters
            T = set(graph) - set(alg_clusters[cluster])
            num_cut_edges = cut_size(graph, alg_clusters[cluster], T, weight=None)
            if num_cut_edges != 0:
                conductances.append(conductance(graph, alg_clusters[cluster]))
            else:
                conductances.append(0)
        else:
            conductances.append(0)
    results = np.mean(conductances)
    return results
# evaluate manta_cluster parameters on the Klemms dataset
# choice of parameters: min_clusters and max_clusters
# edgescale for fuzzy clustering
# convergence is rapid, so limit and iterations should not matter
# however, the number of clusters may affect to what extent
# the k-means algorithm separates central nodes


def plot_results(stats, data, varname, filename, outloc, nan=False):
    """
    Given a file of results, generates the appropriate figure.
    :param stats: Pandas dataframe with results
    :param data: List of lists of cluster assignments
    :param varname: Name of variable that is adjusted
    :param filename: Name for saving image
    :param outloc: Location for saving image
    :param nan: If true, plot # of missing vals. Otherwise, plot avg cluster size.
    :return:
    """
    figure1 = sns.violinplot(x=varname, y="Sep", data=stats, color="gray")
    every_nth = 2
    for n, label in enumerate(figure1.xaxis.get_ticklabels()):
        if n % every_nth != 0:
            label.set_visible(False)# plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    # count number of assignments per var
    textrange = range(-3, len(set(stats[varname]))*10, 10)
    measurements = list(set(stats[varname]))
    for i in range(len(measurements)):
        measure = measurements[i]
        if nan:
            substats = stats[stats[varname] == measure]
            missingno = 50 - substats['Sn'].isnull().values.sum()
        else:
            subdata = data[i]
            no_assignments = list()
            for clusters in subdata:
                total_assignments = 0
                for cluster in clusters:
                    total_assignments += len(cluster)
                no_assignments.append(total_assignments)
            missingno = np.median(no_assignments)
        x = textrange[i] / 10
        if np.max(stats['Sep']) > 0.95:
            y = np.max(stats['Sep']) + 0.15
        else:
            y = np.max(stats['Sep']) + 0.12
        figure1.axes.text(s=str(int(missingno)), x=x, y=y, size=10)
    plt.savefig(outloc + filename, format="pdf", papertype='a4', dpi=1200)
    # allows for visual inspection of plots
    plt.clf()


archive = ".."
replicates = 50
sourcename = archive + "klemm2//graph_"
networks = list()
positive_networks = list()

for i in range(replicates):
    filename = sourcename + str(i + 1) + ".graphml"
    network = nx.read_graphml(filename)
    # shift edges to positive range
    # weights = nx.get_edge_attributes(network, 'weight')
    # minval = np.min(list(weights.values()))
    # for key in weights:
    #    weights[key] -= minval
    # nx.set_edge_attributes(network, weights, 'weight')
    #
    networks.append(network)
    posnet = nx.Graph(((source, target, attr) for source, target, attr in
                       network.edges(data=True) if attr['weight'] > 0))
    positive_networks.append(posnet)

minsize = list()
minsize_fuzzy = list()

for i in range(10):
    manta_clusters = list()
    manta_clusters_fuzzy = list()
    for j in range(50):
        # analyse with manta
        network = networks[j]
        clusters = cluster_graph(network, limit=2, ratio=0, permutations=100, verbose=False,
                                 max_clusters=10, min_clusters=2, iterations=20, subset=0.8,
                                 edgescale=0.8, min_cluster_size=i/10)[0]
        output = nx.get_node_attributes(clusters, name='cluster')
        fuzzy = nx.get_node_attributes(clusters, name='Assignment')
        manta = list()
        # convert dictionary of cluster assignments to
        # cluster lists of nodes
        for k in range(len(set(output.values()))):
            manta.append(list())
            for node in output:
                if len(fuzzy) > 0:
                    if output[node] == list(set(output.values()))[k] and fuzzy[node] != 'Fuzzy':
                        manta[k].append(node)
                else:
                    # memory effect not always present,
                    # fuzziness cannot be determined without memory effect
                    if output[node] == list(set(output.values()))[k]:
                        manta[k].append(node)
        manta_fuzzy = list()
        # convert dictionary of cluster assignments to
        # cluster lists of nodes
        for k in range(len(set(output.values()))):
            manta_fuzzy.append(list())
            for node in output:
                if output[node] == list(set(output.values()))[k]:
                    manta_fuzzy[k].append(node)
        manta_clusters.append(manta)
        manta_clusters_fuzzy.append(manta_fuzzy)
    minsize.append(manta_clusters)
    minsize_fuzzy.append(manta_clusters_fuzzy)

edgescale = list()
edgescale_fuzzy = list()

for i in range(1, 11):
    manta_clusters = list()
    manta_clusters_fuzzy = list()
    for j in range(50):
        # analyse with manta
        network = networks[j]
        network = networks[j]
        clusters = cluster_graph(network, limit=2, ratio=0, permutations=100, verbose=False,
                                 max_clusters=8, min_clusters=2, iterations=20, min_cluster_size=0.1,
                                 edgescale=(i/10), subset=0.8)[0]
        output = nx.get_node_attributes(clusters, name='cluster')
        fuzzy = nx.get_node_attributes(clusters, name='Assignment')
        manta = list()
        # convert dictionary of cluster assignments to
        # cluster lists of nodes
        for k in range(len(set(output.values()))):
            manta.append(list())
            for node in output:
                if len(fuzzy) > 0:
                    if output[node] == list(set(output.values()))[k] and fuzzy[node] != 'Fuzzy':
                        manta[k].append(node)
                else:
                    # memory effect not always present,
                    # fuzziness cannot be determined without memory effect
                    if output[node] == list(set(output.values()))[k]:
                        manta[k].append(node)
        manta_fuzzy = list()
        # convert dictionary of cluster assignments to
        # cluster lists of nodes
        for k in range(len(set(output.values()))):
            manta_fuzzy.append(list())
            for node in output:
                if output[node] == list(set(output.values()))[k]:
                    manta_fuzzy[k].append(node)
        manta_clusters.append(manta)
        manta_clusters_fuzzy.append(manta_fuzzy)
    edgescale.append(manta_clusters)
    edgescale_fuzzy.append(manta_clusters_fuzzy)

subset = list()
subset_fuzzy = list()

for i in range(1, 10):
    manta_clusters = list()
    manta_clusters_fuzzy = list()
    for j in range(50):
        # analyse with manta
        network = networks[j]
        network = networks[j]
        clusters = cluster_graph(network, limit=2, ratio=0, permutations=100, verbose=False,
                                 max_clusters=8, min_clusters=2, iterations=20, min_cluster_size=0.1,
                                 subset=(i/10), edgescale=0.8)[0]
        output = nx.get_node_attributes(clusters, name='cluster')
        fuzzy = nx.get_node_attributes(clusters, name='Assignment')
        manta = list()
        # convert dictionary of cluster assignments to
        # cluster lists of nodes
        for k in range(len(set(output.values()))):
            manta.append(list())
            for node in output:
                if len(fuzzy) > 0:
                    if output[node] == list(set(output.values()))[k] and fuzzy[node] != 'Fuzzy':
                        manta[k].append(node)
                else:
                    # memory effect not always present,
                    # fuzziness cannot be determined without memory effect
                    if output[node] == list(set(output.values()))[k]:
                        manta[k].append(node)
        manta_fuzzy = list()
        # convert dictionary of cluster assignments to
        # cluster lists of nodes
        for k in range(len(set(output.values()))):
            manta_fuzzy.append(list())
            for node in output:
                if output[node] == list(set(output.values()))[k]:
                    manta_fuzzy[k].append(node)
        manta_clusters.append(manta)
        manta_clusters_fuzzy.append(manta_fuzzy)
    subset.append(manta_clusters)
    subset_fuzzy.append(manta_clusters_fuzzy)

ratio = list()
ratio_fuzzy = list()

for i in range(1, 10):
    manta_clusters = list()
    manta_clusters_fuzzy = list()
    for j in range(50):
        # analyse with manta
        network = networks[j]
        network = networks[j]
        clusters = cluster_graph(network, limit=2, ratio=(i/10), permutations=100, verbose=False,
                                 max_clusters=8, min_clusters=2, iterations=20,
                                 edgescale=0.8, subset= 0.8, min_cluster_size=0.2)[0]
        output = nx.get_node_attributes(clusters, name='cluster')
        fuzzy = nx.get_node_attributes(clusters, name='Assignment')
        manta = list()
        # convert dictionary of cluster assignments to
        # cluster lists of nodes
        for k in range(len(set(output.values()))):
            manta.append(list())
            for node in output:
                if len(fuzzy) > 0:
                    if output[node] == list(set(output.values()))[k] and fuzzy[node] != 'Fuzzy':
                        manta[k].append(node)
                else:
                    # memory effect not always present,
                    # fuzziness cannot be determined without memory effect
                    if output[node] == list(set(output.values()))[k]:
                        manta[k].append(node)
        manta_fuzzy = list()
        # convert dictionary of cluster assignments to
        # cluster lists of nodes
        for k in range(len(set(output.values()))):
            manta_fuzzy.append(list())
            for node in output:
                if output[node] == list(set(output.values()))[k]:
                    manta_fuzzy[k].append(node)
        manta_clusters.append(manta)
        manta_clusters_fuzzy.append(manta_fuzzy)
    ratio.append(manta_clusters)
    ratio_fuzzy.append(manta_clusters_fuzzy)

# manta params
#edgescale
#edgescale_fuzzy
manta_edge = pd.DataFrame(np.zeros(shape=(10*50, 7)))
manta_edge.columns = ['Edge scale', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
manta_fuzzy_edge = pd.DataFrame(np.zeros(shape=(10*50, 7)))
manta_fuzzy_edge.columns = ['Edge scale', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
k = 0
for j in range(10):
    parameter = list(range(1, 11))[j]/10
    for i in range(50):
        manta_edge.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], edgescale[j][i])
        manta_edge.iloc[k, 1] = results[0]
        manta_edge.iloc[k, 2] = results[1]
        manta_edge.iloc[k, 3] = results[2]
        manta_edge.iloc[k, 4] = results[3]
        manta_edge.iloc[k, 5] = cluster_sparsity(networks[i], edgescale[j][i])
        results = cluster_quality(networks[i], edgescale[j][i])
        manta_edge.iloc[k, 6] = results
        manta_fuzzy_edge.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], edgescale_fuzzy[j][i])
        manta_fuzzy_edge.iloc[k, 1] = results[0]
        manta_fuzzy_edge.iloc[k, 2] = results[1]
        manta_fuzzy_edge.iloc[k, 3] = results[2]
        manta_fuzzy_edge.iloc[k, 4] = results[3]
        manta_fuzzy_edge.iloc[k, 5] = cluster_sparsity(networks[i], edgescale_fuzzy[j][i])
        results = cluster_quality(networks[i], edgescale_fuzzy[j][i])
        manta_fuzzy_edge.iloc[k, 6] = results
        k += 1

# manta params
# subset
# subset_fuzzy
manta_subset = pd.DataFrame(np.zeros(shape=(9*50, 7)))
manta_subset.columns = ['Subset fraction', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
manta_fuzzy_subset = pd.DataFrame(np.zeros(shape=(9*50, 7)))
manta_fuzzy_subset.columns = ['Subset fraction', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
k = 0
for j in range(9):
    parameter = list(range(1, 11))[j]/10
    for i in range(50):
        manta_subset.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], subset[j][i])
        manta_subset.iloc[k, 1] = results[0]
        manta_subset.iloc[k, 2] = results[1]
        manta_subset.iloc[k, 3] = results[2]
        manta_subset.iloc[k, 4] = results[3]
        manta_subset.iloc[k, 5] = cluster_sparsity(networks[i], subset[j][i])
        results = cluster_quality(networks[i], subset[j][i])
        manta_subset.iloc[k, 6] = results
        manta_fuzzy_subset.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], subset_fuzzy[j][i])
        manta_fuzzy_subset.iloc[k, 1] = results[0]
        manta_fuzzy_subset.iloc[k, 2] = results[1]
        manta_fuzzy_subset.iloc[k, 3] = results[2]
        manta_fuzzy_subset.iloc[k, 4] = results[3]
        manta_fuzzy_subset.iloc[k, 5] = cluster_sparsity(networks[i], subset_fuzzy[j][i])
        results = cluster_quality(networks[i], subset_fuzzy[j][i])
        manta_fuzzy_subset.iloc[k, 6] = results
        k += 1


# manta params
#ratio
#ratio_fuzzy
manta_ratio = pd.DataFrame(np.zeros(shape=(9*50, 7)))
manta_ratio.columns = ['Ratio', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
manta_fuzzy_ratio = pd.DataFrame(np.zeros(shape=(9*50, 7)))
manta_fuzzy_ratio.columns = ['Ratio', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']

k = 0
for j in range(9):
    parameter = list(range(1, 10))[j]/10
    for i in range(50):
        manta_ratio.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], ratio[j][i])
        manta_ratio.iloc[k, 1] = results[0]
        manta_ratio.iloc[k, 2] = results[1]
        manta_ratio.iloc[k, 3] = results[2]
        manta_ratio.iloc[k, 4] = results[3]
        manta_ratio.iloc[k, 5] = cluster_sparsity(networks[i], ratio[j][i])
        results = cluster_quality(networks[i], ratio[j][i])
        manta_ratio.iloc[k, 6] = results
        manta_fuzzy_ratio.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], ratio_fuzzy[j][i])
        manta_fuzzy_ratio.iloc[k, 1] = results[0]
        manta_fuzzy_ratio.iloc[k, 2] = results[1]
        manta_fuzzy_ratio.iloc[k, 3] = results[2]
        manta_fuzzy_ratio.iloc[k, 4] = results[3]
        manta_fuzzy_ratio.iloc[k, 5] = cluster_sparsity(networks[i], ratio_fuzzy[j][i])
        results = cluster_quality(networks[i], ratio_fuzzy[j][i])
        manta_fuzzy_ratio.iloc[k, 6] = results
        k += 1

# manta params
#minsize
#minsize_fuzzy
manta_minsize = pd.DataFrame(np.zeros(shape=(10*50, 7)))
manta_minsize.columns = ['Minsize', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']
manta_fuzzy_minsize = pd.DataFrame(np.zeros(shape=(10*50, 7)))
manta_fuzzy_minsize.columns = ['Minsize', 'Sn', 'PPV', 'Acc', 'Sep', 'Sparsity', 'Conductance']

k = 0
for j in range(10):
    parameter = list(range(10))[j]/10
    for i in range(50):
        manta_minsize.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], minsize[j][i])
        manta_minsize.iloc[k, 1] = results[0]
        manta_minsize.iloc[k, 2] = results[1]
        manta_minsize.iloc[k, 3] = results[2]
        manta_minsize.iloc[k, 4] = results[3]
        manta_minsize.iloc[k, 5] = cluster_sparsity(networks[i], minsize[j][i])
        results = cluster_quality(networks[i], minsize[j][i])
        manta_minsize.iloc[k, 6] = results
        manta_fuzzy_minsize.iloc[k, 0] = parameter
        results = cluster_comparison(env_clusters[i], minsize_fuzzy[j][i])
        manta_fuzzy_minsize.iloc[k, 1] = results[0]
        manta_fuzzy_minsize.iloc[k, 2] = results[1]
        manta_fuzzy_minsize.iloc[k, 3] = results[2]
        manta_fuzzy_minsize.iloc[k, 4] = results[3]
        manta_fuzzy_minsize.iloc[k, 5] = cluster_sparsity(networks[i], minsize_fuzzy[j][i])
        results = cluster_quality(networks[i], minsize_fuzzy[j][i])
        manta_fuzzy_minsize.iloc[k, 6] = results
        k += 1

# manta params
#manta_k
#manta_fuzzy_k
#manta_edge
#manta_fuzzy_edge
#manta_subset
#manta_fuzzy_subset
#manta_ratio
#manta_fuzzy_ratio
#louvain_resolution
#louvain_positive_resolution
#mcl_expansion
#mcl_positive_expansion
#mcl_inflation
#mcl_positive_inflation
#kernighan_iteration
#kernighan_positive_iteration
outloc = archive + "params//"
manta_fuzzy_edge.to_csv(outloc+"manta_fuzzy_edge.csv") # no fuzzy clusters, should be no difference
manta_edge.to_csv(outloc+"manta_edge.csv") # includes fuzzy clusters
manta_fuzzy_subset.to_csv(outloc+"manta_fuzzy_subset.csv") # no fuzzy clusters, should be no difference
manta_subset.to_csv(outloc+"manta_subset.csv") # includes fuzzy clusters
manta_fuzzy_ratio.to_csv(outloc+"manta_fuzzy_ratio.csv")
manta_ratio.to_csv(outloc+"manta_ratio.csv")
manta_minsize.to_csv(outloc+"manta_minsize.csv")
manta_fuzzy_minsize.to_csv(outloc+"manta_fuzzy_minsize.csv")

manta_edge = pd.read_csv(outloc+"manta_edge.csv")
manta_fuzzy_edge = pd.read_csv(outloc+"manta_fuzzy_edge.csv")
manta_ratio = pd.read_csv(outloc+"manta_ratio.csv")
manta_fuzzy_subset = pd.read_csv(outloc+"manta_fuzzy_subset.csv")
manta_subset = pd.read_csv(outloc+"manta_subset.csv")

sns.set(style="whitegrid", palette="cubehelix")

# if nan is true, counts number of missing assignments
# if nan is false (default), gives median cluster size
plot_results(stats=manta_edge, data=edgescale, nan=True,
             varname="Edge scale", filename="manta_edge.pdf", outloc=outloc)
plot_results(stats=manta_ratio, data=ratio, nan=True,
             varname="Ratio", filename="manta_ratio.pdf", outloc=outloc)
plot_results(stats=manta_minsize, data=minsize, nan=True,
             varname="Minsize", filename="manta_minsize.pdf", outloc=outloc)
plot_results(stats=manta_fuzzy_edge, data=edgescale_fuzzy, nan=True,
             varname="Edge scale", filename="manta_fuzzy_edge.pdf", outloc=outloc)
plot_results(stats=manta_fuzzy_ratio, data=ratio_fuzzy, nan=True,
             varname="Ratio", filename="manta_fuzzy_ratio.pdf", outloc=outloc)
plot_results(stats=manta_fuzzy_minsize, data=minsize_fuzzy, nan=True,
             varname="Minsize", filename="manta_fuzzy_minsize.pdf", outloc=outloc)
plot_results(stats=manta_fuzzy_subset, data=subset_fuzzy, nan=True,
             varname="Subset fraction", filename="manta_fuzzy_subset.pdf", outloc=outloc)
plot_results(stats=manta_subset, data=subset, nan=True,
             varname="Subset fraction", filename="manta_subset.pdf", outloc=outloc)
