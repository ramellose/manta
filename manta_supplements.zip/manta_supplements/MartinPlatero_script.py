from manta.cluster import cluster_graph
import networkx as nx
import pandas as pd
from manta.cyjson import write_cyjson
import numpy as np

archive = ".."
filename = archive + "time/platero_elsa_out.txt"

graph = nx.Graph()

raw = pd.read_table(filename)
for index, row in raw.iterrows():
    if row['P'] < 0.05 and row['Q'] < 0.05:
        graph.add_edge(row['X'], row['Y'], weight=row['LS'], Len=row['Len'], Delay=row['Delay'])


# add taxonomy
tax = pd.read_table(archive + "time//platero_tax.txt")
labels = ['Kingdom', 'Phylum', 'Class', 'Order', 'Family', 'Genus', 'Species']
for i in range(7):
    taxdict = dict.fromkeys([str(x) for x in tax.index])
    for j in range(len(taxdict)):
        name = tax.index[j]
        taxdict[str(name)] = str(tax.iloc[j, i])
    nx.set_node_attributes(graph, values=taxdict, name=labels[i])

orig_edges = dict()
for edge in graph.edges:
    orig_edges[edge] = graph.edges[edge]['weight']
    graph.edges[edge]['weight'] = np.sign(graph.edges[edge]['weight'])

results = cluster_graph(graph, limit=2, max_clusters=15, min_clusters=2, iterations=20, verbose=True,
                        min_cluster_size=0.2, ratio=0.8, edgescale=0.2, permutations=100, subset=0.8)
graph = results[0]
for edge in graph.edges:
    graph.edges[edge]['weight'] = orig_edges[edge]

nx.write_graphml(graph, archive + 'time//platero_clustered.graphml')

#################
# directed graph
filename = archive + "time//platero_elsa_out.txt"
graph = nx.DiGraph()
raw = pd.read_table(filename)
for index, row in raw.iterrows():
    if row['P'] < 0.05 and row['Q'] < 0.05:
        graph.add_edge(row['X'], row['Y'], weight=row['LS'], Len=row['Len'], Delay=row['Delay'])

# add taxonomy
tax = pd.read_table(archive + "time//platero_tax.txt")
labels = ['Kingdom', 'Phylum', 'Class', 'Order', 'Family', 'Genus', 'Species']
for i in range(7):
    taxdict = dict.fromkeys([str(x) for x in tax.index])
    for j in range(len(taxdict)):
        name = tax.index[j]
        taxdict[str(name)] = str(tax.iloc[j, i])
    nx.set_node_attributes(graph, values=taxdict, name=labels[i])

results = cluster_graph(graph, limit=2, max_clusters=15, min_clusters=2, iterations=5, verbose=True,
                        min_cluster_size=0.1, ratio=0.8, edgescale=0.8, permutations=100, subset=0.8)

nx.write_graphml(results[0], archive + 'time//platero_clustered_directed.graphml')
