# This file contains the code required for generating permuted graphs. 
# The filepaths have been adjusted and may not be entirely correct;
# please fix these for your own system. 

setwd("..")

library(SpiecEasi)
library(igraph)
library(Hmisc)
library(WGCNA)

sims <- list(readRDS("random2/50envreplicates_random2.rds"),
             readRDS("random3/50envreplicates_random3.rds"), 
             readRDS("fabia2/fabia2clusters.rds"),
             readRDS("fabia3/fabia3clusters.rds"))
graphnames <- c("random2/graph_perm_",
                "random3/graph_perm_",
                "fabia2/graph_perm_",
                "fabia3/graph_perm_")
wgcnanames <- c("random2/",
                "random3/",
                "fabia2/",
                "fabia3/")

permsims = list()
sizes <- seq(0, 10000, by=1000)
c = 1
for (c in 1:10){
  # write all matrices to format that can be read by networkx
  for (j in 1:4){
    alldata = sims[[j]]
    for (s in 1:50){
      data <- alldata[[s]]
      # permute % of values
      for (k in 1:((c*0.1)*8000)){
        positions <- sample(1:8000, 2)
        vals <- c(data[positions[1]], data[positions[2]])
        data[positions[2]] <- vals[1]
        data[positions[1]] <- vals[2]
      }
      result <- rcorr(t(data))
      graph <- result$r
      graph[is.na(graph)] <- 0
      graph[result$P > 0.05] <- 0
      for (i in 1:100){
        for (k in 1:100){
          if (i == k){
            graph[i,i] <- 0
          }
        }
      }
    
    # remove nodes with only 0s
    rem_nodes <- colSums(graph != 0)
    rem_nodes <- rem_nodes != 0
    graph <- graph[rem_nodes, rem_nodes]
    graph <- graph_from_adjacency_matrix(graph, weighted=TRUE, mode=c("undirected"))
    name <- paste(graphnames[j], c, "_",  s, ".graphml", sep="")
    write_graph(graph, file=name, format="graphml")
    
    # WGCNA
    dynamicMods <- blockwiseModules(t(data), networkType = "signed", TOMType="signed")
    dynamicMods <- dynamicMods$colors
    # generate dictionary of ints
    dynamicMods[dynamicMods == "grey"] <- 0
    for (b in 1:length(unique(dynamicMods))){
      color <- unique(dynamicMods)[[b]]
      if (color != 0){
        dynamicMods[dynamicMods == color] <- b
      }
    }
    write.csv(dynamicMods, paste(wgcnanames[j],c, "_",  s, "_wgcna_signed_perm.csv", sep=""))
    dynamicMods <- blockwiseModules(t(data), networkType = "unsigned", TOMType="unsigned")
    dynamicMods <- dynamicMods$colors
    # generate dictionary of ints
    dynamicMods[dynamicMods == "grey"] <- 0
    for (b in 1:length(unique(dynamicMods))){
      color <- unique(dynamicMods)[[b]]
      if (color != 0){
        dynamicMods[dynamicMods == color] <- b
      }
    }
    write.csv(dynamicMods, paste(wgcnanames[j], c, "_", s, "_wgcna_unsigned_perm.csv", sep=""))
    }
  }
}
