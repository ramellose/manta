# generate environmentally-induced clusters with Pearson correlation using the env dataset functions
# cluster networks in Python + evaluate how many taxa are assigned to the correct environment
source("generateSets.R")
source("envGrowthChanges.R")
# minor changes from original env growth changes; instead of changing conditions, we keep conditions constant and report env effect on taxa

n = 50 # number of replicates
species = 100
samples = 80
name = "env_clusters"
strength = 0.9 # much higher than this and SPIEC-EASI will not return networks   3dec2 has strength 0.3, 3dec3 0.7, 3dec4 0.9 
conditions = 2 # let's start out with 2 clusters, 1 condition
env.factors = 2

setwd("../random2")
alldata = list()
# some sets crash the solver, should generate 1 by 1
b = 1
for (i in b:n){
  subname <- i
  b = i 
  data <- generateSets(n=1, species=species, samples=samples, name=subname, strength=strength, conditions=conditions, env.factors=env.factors, mode='random')
  alldata[[i]] <- data[[1]]
  print(b)
}

saveRDS(alldata, "50envreplicates_random2.rds")

# first get true positives; list of organisms negatively affected in condition 1 vs 2 
envdata = list()
for (i in 1:n){
  env <- readRDS(paste(i, "_envfactors.rds", sep=""))
  envdata[[i]] <- env[[1]]
}
saveRDS(envdata, "50envreplicates_envfactors_random2.rds")

envdata <- readRDS("50envreplicates_envfactors_random2.rds")
datasets <- readRDS("50envreplicates_random2.rds")

# get list of feature effects on taxon growth
features <- list()
true_positive_clusters <- list()
for (i in 1:n){
  features[[i]] = envdata[[i]][[2]]
  true_positive_clusters[[i]] <- vector()
  for (j in 1:species){
    if (features[[i]][[j]] < 0){
      true_positive_clusters[[i]][[j]] <- 1
    }
    else {
      true_positive_clusters[[i]][[j]] <- 2
    }
  }
  names(true_positive_clusters[[i]]) <- rownames(datasets[[1]])
}

# write dataset to share
setwd("../random2")
for (i in 1:n){
  set = datasets[[i]]
  string = paste(i,".txt", sep="")
  write.table(set, string, sep="\t", col.names=NA)
}
##### write envdata to Python-readable files
setwd("../random2")
for (i in 1:n){
  env <- envdata[[i]][[3]]
  write.csv(env, file=paste('growthrates_', i, '.csv', sep=''))
}

library(Hmisc)
graphs <- list()
for (j in 1:length(datasets)){
  result <- rcorr(t(datasets[[j]]))
  graphs[[j]] <- result$r
  graphs[[j]][result$P > 0.05] <- 0
  for (i in 1:species){
    for (k in 1:species){
      if (i == k){
        graphs[[j]][i,i] <- 0
      }
    }
  }
  # remove nodes with only 0s
  rem_nodes <- colSums(graphs[[j]] != 0)
  rem_nodes <- rem_nodes != 0
  graphs[[j]] <- graphs[[j]][rem_nodes, rem_nodes]
}

library(igraph)
# write all matrices to format that can be read by networkx
for (i in 1:n){
  graph <- graphs[[i]]
  graph <- graph_from_adjacency_matrix(graph, weighted=TRUE, mode=c("undirected"))
  name <- paste(getwd(), "/graph_", i, ".graphml", sep="")
  write_graph(graph, file=name, format="graphml")
}

setwd("../random2")
alldata <- readRDS("50envreplicates_random2.rds")

library(WGCNA)
for (i in 1:50){
  # 0 is for unassigned nodes
  dynamicMods <- blockwiseModules(t(alldata[[i]]), networkType = "signed", TOMType="signed")
  dynamicMods <- dynamicMods$colors
  # generate dictionary of ints
  dynamicMods[dynamicMods == "grey"] <- 0
  for (b in 1:length(unique(dynamicMods))){
    color <- unique(dynamicMods)[[b]]
    if (color != 0){
      dynamicMods[dynamicMods == color] <- b
    }
  }
  write.csv(dynamicMods, paste(i, "_wgcna_signed.csv", sep=""))
}


for (i in 1:50){
  dynamicMods <- blockwiseModules(t(alldata[[i]]), networkType = "unsigned", TOMType="unsigned")
  dynamicMods <- dynamicMods$colors
  # generate dictionary of ints
  dynamicMods[dynamicMods == "grey"] <- 0
  for (b in 1:length(unique(dynamicMods))){
    color <- unique(dynamicMods)[[b]]
    if (color != 0){
      dynamicMods[dynamicMods == color] <- b
    }
  }
  write.csv(dynamicMods, paste(i, "_wgcna_unsigned.csv", sep=""))
}

# shift edge weights into positive range
for (i in 1:n){
  graph <- graphs[[i]]
  graph <- t(apply(graph, 1, function(x)(x-min(x))/(max(x)-min(x))))
  graph <- graph_from_adjacency_matrix(graph, weighted=TRUE, mode=c("undirected"))
  name <- paste(getwd(), "/graph_normalized_", i, ".graphml", sep="")
  write_graph(graph, file=name, format="graphml")
}


################ 
### 3 clusters
################

n = 50 # number of replicates
species = 100
samples = 90
name = "env_clusters"
strength = 1 # much higher than this and SPIEC-EASI will not return networks   3dec2 has strength 0.3, 3dec3 0.7, 3dec4 0.9 
conditions = 3 # let's start out with 2 clusters, 1 condition
env.factors = 3

setwd("random3")
alldata = list()
# some sets crash the solver, should generate 1 by 1 
b = 1
for (i in b:n){
  subname <- i
  b = i
  data <- generate3Sets(n=1, species=species, samples=samples, name=subname, strength=strength, conditions=conditions, env.factors=env.factors, mode='random')
  alldata[[i]] <- data[[1]]
  print(b)
}
heatmap(as.matrix(alldata[[1]]))

saveRDS(alldata, "50envreplicates_random3.rds")

# first get true positives; list of organisms negatively affected in condition 1 vs 2 
envdata = list()
for (i in 1:n){
  env <- readRDS(paste(i, "_envfactors.rds", sep=""))
  envdata[[i]] <- env[[1]]
}
saveRDS(envdata, "50envreplicates_envfactors_random3.rds")

envdata <- readRDS("50envreplicates_envfactors_random3.rds")
datasets <- readRDS("50envreplicates_random3.rds")

# get list of feature effects on taxon growth
features <- list()
true_positive_clusters <- list()
for (i in 1:n){
  features[[i]] = envdata[[i]][[2]]
  true_positive_clusters[[i]] <- vector()
  for (j in 1:species){
    if (features[[i]][[j]] < 0){
      true_positive_clusters[[i]][[j]] <- 1
    }
    else {
      true_positive_clusters[[i]][[j]] <- 2
    }
  }
  names(true_positive_clusters[[i]]) <- rownames(datasets[[1]])
}

# write dataset to share
setwd("../random3")
for (i in 1:n){
  set = datasets[[i]]
  string = paste(i,".txt", sep="")
  write.table(set, string, sep="\t", col.names=NA)
}
##### write envdata to Python-readable files
setwd("../random3")
for (i in 1:n){
  env <- envdata[[i]][[3]]
  write.csv(env, file=paste('growthrates_', i, '.csv', sep=''))
}

library(Hmisc)
graphs <- list()
for (j in 1:length(datasets)){
  result <- rcorr(t(datasets[[j]]))
  graphs[[j]] <- result$r
  graphs[[j]][result$P > 0.05] <- 0
  for (i in 1:species){
    for (k in 1:species){
      if (i == k){
        graphs[[j]][i,i] <- 0
      }
    }
  }
  # remove nodes with only 0s
  rem_nodes <- colSums(graphs[[j]] != 0)
  rem_nodes <- rem_nodes != 0
  graphs[[j]] <- graphs[[j]][rem_nodes, rem_nodes]
}

library(igraph)
# write all matrices to format that can be read by networkx
for (i in 1:n){
  graph <- graphs[[i]]
  graph <- graph_from_adjacency_matrix(graph, weighted=TRUE, mode=c("undirected"))
  name <- paste(getwd(), "/graph_", i, ".graphml", sep="")
  write_graph(graph, file=name, format="graphml")
}

setwd("../random3")
alldata <- readRDS("50envreplicates_random3.rds")

library(WGCNA)
for (i in 1:50){
  # 0 is for unassigned nodes
  dynamicMods <- blockwiseModules(t(alldata[[i]]), networkType = "signed", TOMType="signed")
  dynamicMods <- dynamicMods$colors
  # generate dictionary of ints
  dynamicMods[dynamicMods == "grey"] <- 0
  for (b in 1:length(unique(dynamicMods))){
    color <- unique(dynamicMods)[[b]]
    if (color != 0){
      dynamicMods[dynamicMods == color] <- b
    }
  }
  write.csv(dynamicMods, paste(i, "_wgcna_signed.csv", sep=""))
}


for (i in 1:50){
  dynamicMods <- blockwiseModules(t(alldata[[i]]), networkType = "unsigned", TOMType="unsigned")
  dynamicMods <- dynamicMods$colors
  # generate dictionary of ints
  dynamicMods[dynamicMods == "grey"] <- 0
  for (b in 1:length(unique(dynamicMods))){
    color <- unique(dynamicMods)[[b]]
    if (color != 0){
      dynamicMods[dynamicMods == color] <- b
    }
  }
  write.csv(dynamicMods, paste(i, "_wgcna_unsigned.csv", sep=""))
}

