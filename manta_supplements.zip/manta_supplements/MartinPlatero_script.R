setwd("time")

library(phyloseq)
library(igraph)
library(ggplot2)
library(Hmisc)
library(vegan)
library(viridis)
source('../triplot.R')

prevFilter = function(phy, prev){
  prev0 = apply(X = otu_table(phy),
                MARGIN = ifelse(taxa_are_rows(phy), yes = 1, no = 2),
                FUN = function(x){sum(x > 0)})
  prevalenceThreshold = prev * nsamples(phy)
  nonrares = prune_taxa((prev0 > prevalenceThreshold), phy)
  rares = prune_taxa((prev0 < prevalenceThreshold), phy)
  rares = merge_taxa(rares, taxa_names(rares))
  otus = data.frame(otu_table(nonrares))
  otus = rbind(otus, data.frame(otu_table(rares)))
  tax = data.frame(tax_table(nonrares), stringsAsFactors = FALSE)
  tax = rbind(tax, c("Bacteria", rep(NA, 6)))
  rownames(tax)[length(rownames(tax))] = taxa_names(rares)
  colnames(otus) <- rownames(sample_data(phy))  # checked manually if this is correct; data.frame adds an X for every name
  newphy = phyloseq(otu_table(otus, taxa_are_rows = TRUE), sample_data(phy), tax_table(as.matrix(tax)))
  return(newphy)
}

preprocess = function(phy, rar, prev, name){
  lowcounts <- sample_sums(phy)
  names(lowcounts) <- sample_names(phy)
  lowcounts <- lowcounts[sample_sums(phy) < rar]
  phylo <- prune_samples((!sample_names(phy) %in% names(lowcounts)), phy)
  set.seed(7)
  # rarefy to even depth
  phylo <- rarefy_even_depth(phylo)
  # 20% prevalence filter
  phylo <- prevFilter(phylo, prev)
  otuname <- paste(name, ".rds", sep="")
  saveRDS(phylo, otuname)  #10% prevalence, rarefied to 2000 sequences
  otus <- data.frame(otu_table(phylo))
  otuname <- paste(name, "_otu.txt", sep="")
  write.table(otus, otuname, quote=FALSE, sep="\t")
  return(phylo)
}

name = "platero"

data <- read.table("platero_data.txt")
otus <- data[2:28593, 2:266]
names <- unlist(data[1,2:266])
colnames(otus) <- names
rownames(otus) <- data[2:28593,1]
# separate taxonomy
data <- otus$ConsensusLineage
otus$ConsensusLineage <- NULL
# only 90 days in otu table!
tax <- data.frame(matrix(nrow=dim(otus)[1], ncol=7))
colnames(tax) <- c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species")
for (j in 1:dim(otus)[1]){
  item <- data[j]
  levels <- unlist(strsplit(as.character(item), ";"))
  for (i in 1:7){
    level <- levels[i]
    if (nchar(level) > 3){
      tax[j,i] <- level
    }
  }
}
rownames(tax) <- rownames(otus)
taxname <- paste(name, "_tax.txt", sep="")
write.table(tax, taxname, quote=FALSE, sep="\t")

raw <- read.csv("platero_meta.txt", sep="\t")
# link ordinal day measurements to others
meta <- data.frame(matrix(nrow=length(colnames(otus)), ncol=length(colnames(raw))))
colnames(meta) <- colnames(raw)
rownames(meta) <- colnames(otus)
rep <- c()
for (i in 1:length(rownames(meta))){
  name <- as.character(rownames(meta)[i])
  day <- unlist(strsplit(name, "[.]"))[2]
  daydata <- raw[raw$OrdinalDay == day,]
  meta[i,] <- daydata
  replicate <- unlist(strsplit(name, "[.]"))[3]
  rep <- c(rep, replicate)
}
meta$Replicate <- rep

otus <- data.frame(sapply(otus, function(x) as.numeric(as.character(x))))
rownames(otus) <- rownames(tax)
colnames(otus) <- rownames(meta)
tax <- as.matrix(tax)
phylo <- phyloseq(otu_table(otus, taxa_are_rows=TRUE), sample_data(meta), tax_table(tax))

# alm is rarefied, but not tax glom
# alm_small has tax_glom; updated ver alm_small_v2
# both have rar 5000, prev 0.3
# alm_small2 has prev 0.3
phylo <- tax_glom(phylo, taxrank="Genus", NArm=FALSE)
phylo <- preprocess(phylo, rar=2000, prev=0.3, name="platero")

saveRDS(phylo, "platero_phylo.rds")

gp_bray_pcoa = ordinate(phylo, "PCoA", "bray")
plot_ordination(phylo, gp_bray_pcoa, "samples", color="OrdinalDay") + theme_minimal() + labs(color="day") +
  xlab("PCoA 1 [39.4%]") + ylab("PCoA 2 [15.5%]") + labs(color="Day") + scale_color_viridis() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), 
        axis.line = element_line(colour = "black"), axis.text.x = element_blank(), axis.ticks = element_blank(), axis.text.y = element_blank()) + coord_flip()

# samples are in triplicates
# need to combine into a  dataframe
# 3 replicates, 93 days
otus <- data.frame(otu_table(phylo))
meta <- data.frame(sample_data(phylo))
colnames(otus) <- rownames(meta)
timepoints <- unique(meta$OrdinalDay)
names <- c()
for (time in timepoints){
  replicates <- c(paste("10N", time, "37", sep="."), paste("10N", time, "38", sep="."), paste("10N", time, "39", sep="."))
  names <- c(names, replicates)
}
elsa <- data.frame(matrix(ncol=length(names), nrow=dim(otus)[1]))
colnames(elsa) <- names
rownames(elsa) <- rownames(otus)
for (i in 1:length(names)){
  sample <- names[i]
  if (sample %in% colnames(otus)){
    elsa[,i] <- otus[sample]
  }
}
write.table(elsa, "platero_elsa_in.txt", quote=FALSE, sep="\t")
# these files are used to run eLSA

######### analysis of graph results

phylo <- readRDS("platero_phylo.rds")
graph <- read_graph("platero_clustered.graphml", format="graphml")
# get OTU table per time series
# average it like eLSA supplied
otus <- data.frame(otu_table(phylo))
meta <- data.frame(sample_data(phylo))
timepoints <- unique(meta$OrdinalDay)
days <- meta$OrdinalDay

avg <- data.frame(matrix(nrow=length(rownames(otus)), ncol=length(timepoints)))
rownames(avg) <- rownames(otus)
colnames(avg) <- timepoints
avg_meta <- data.frame(matrix(nrow=length(timepoints), ncol=length(colnames(meta))))
for (i in 1:length(timepoints)){
  point <- timepoints[i]
  otu_ids <- which(days == point)
  if (length(otu_ids) > 1){
    sample_id <- otu_ids[1]
    otu_cols <- rowMeans(otus[,otu_ids])
  }
  else {
    otu_cols <- otus[,otu_ids]
  }
  avg_meta[i,] <- meta[sample_id,]
  avg[,i] <- otu_cols
}
colnames(avg_meta) <- colnames(meta)
# actually, the colnames are changed to easier to read vars
colnames(avg_meta) <- c("Day", "Air temperature_Celsius", "Ammonium_uM", "Atmospheric pressure",
                        "Chlorophyll_uM", "Dominant wave period", "Macroalgae", "Nitrite.Nitrate_uM",
                        "Phosphate_uM", "Salinity_PPT", "Silicate_uM", 
                        "Tidal direction", "Water level_m", "Water temperature_Celsius", "Wave height_m", 
                        "Wind speed_m.s", "Replicate")
rownames(avg_meta) <- colnames(avg)
# drop day as a factor
avg_phylo <- phyloseq(otu_table(avg, taxa_are_rows = TRUE), tax_table(phylo), sample_data(avg_meta))

# get vectors of cluster ids
clusterframe <- data.frame(matrix(nrow=length(V(graph)), ncol=3))
colnames(clusterframe) <- c("OTU", "Cluster", "Assignment")
i = 1
otus <- c()
cluster <- c()
assignment <- c()
for (node in V(graph)){
  otus <- c(otus, get.vertex.attribute(graph, 'id', node))
  cluster <- c(cluster, get.vertex.attribute(graph, 'cluster', node))
  assignment <- c(assignment, get.vertex.attribute(graph, 'assignment', node))
  i = i + 1
}
clusterframe$OTU <- otus
clusterframe$Cluster <- cluster
clusterframe$Assignment <- assignment
otu_clusters <- c()
for (otu in taxa_names(avg_phylo)){
  otu_clusters <- c(otu_clusters, clusterframe$Cluster[clusterframe$OTU == otu])
  if (clusterframe$Assignment[clusterframe$OTU == otu] == 'weak'){
    otu_clusters <- c(otu_clusters, 'weak')
  }
  else {
    otu_clusters <- c(otu_clusters, clusterframe$Cluster[clusterframe$OTU == otu])
  }
}
# not so many weak assignments, so we can probably ignore for statistics

# correlate clusters to metadata vars
# added var in triplot to add vectors for clustered taxon abundances
triplot <- seqPCoA(avg_phylo, groupAttrib='Day', topTaxa=0, clusterTaxon=otu_clusters,
                   topMetadata=10, metadataFactor=0.6, arrowFactor=0.00021) + labs(color='Day') + scale_color_viridis()
triplot

#### make abundance plots
# get Y object from seqPCoA internals

colnames(Y) <- unique(otu_clusters)
rownames(Y) <- timepoints
total_abundances <- reshape2::melt(Y)

ggplot(data=total_abundances, aes(x=Var1, y=value, color=Var2)) + geom_line() + scale_color_viridis_d() + theme_minimal() + labs(y="Summed abundances", x="Days", color="Cluster")

